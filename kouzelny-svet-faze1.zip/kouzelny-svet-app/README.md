# Kouzelný svět – fáze 1

Pohádkový učitel pro děti 4–8 let. Postavička (Fousek Kapelník, Sova Lili nebo Bublík) provází dítě domečkem s pokoji. Každý pokoj je jedno dobrodružství, které učí přes hru, ne přes kvíz.

## Co je hotové

| Pokoj | Lekce | Co rozvíjí | Metoda |
| --- | --- | --- | --- |
| Ostrov čísel | Ztracený koláček | pojmenování, přiřazení 1:1, kolik chybí, pozornost, kresba | Hejný, Feuerstein, Montessori, HYPO |
| Les slov | Orchestr slabik | rytmus a slabiky | Elkonin (krok 2) |
| Dům samostatnosti | Mytí rukou | posloupnost, plánování, jemná motorika, počítání do 10 | Feuerstein, Montessori |
| Zahrada emocí | – | připraveno pro fázi 2 | |

Každá lekce končí úkolem mimo obrazovku a otázkou „Na co jsi dnes pyšná?“.

**Žebřík nápověd** u každé úlohy: 1. chyba → nápovědná otázka a zvýraznění, 2. chyba → postavička ukáže řešení („Já se taky někdy spletu“). Výsledek se zapíše jako *samostatně / s nápovědou / s ukázkou*.

**Adaptace** (`src/adaptive.ts`): úroveň se zvýší po dvou úspěšných kolech za sebou (≥ 80 % samostatně a žádná ukázka), sníží po dvou těžkých kolech. Rychlost se nikdy nezohledňuje.

**Rodičovská sekce** za bránou (číslo napsané slovy): mapa dovedností, strategie dítěte, tipy na společnou hru doma (až po aspoň dvou pozorováních), galerie kreseb, nastavení, export a smazání dat.

**Soukromí:** vše jen v zařízení (localStorage), nic se neodesílá, mikrofon se nepoužívá.

**Offline:** po prvním otevření funguje bez internetu (service worker). Na iPadu: Safari → Sdílet → Přidat na plochu.

## Spuštění

```bash
npm install
npm run dev          # vývoj na http://localhost:5173
npm run build        # produkční PWA do dist/
npm run build:single # jeden HTML soubor do dist-single/ (náhled bez serveru, bez offline režimu)
```

Na iPadu doporučujeme stáhnout český hlas: Nastavení › Zpřístupnění › Předčítaný obsah › Hlasy › Čeština (Zuzana).

## Testy

```bash
npm test             # jednotkové testy (Vitest)
npm run test:e2e     # end-to-end testy (Playwright) na iPadu na šířku, na výšku a na telefonu
npm run check        # typy + jednotkové + build + e2e
```

* **Jednotkové (34):** čeština (čísla, skloňování), adaptace, validace obsahu (slabiky musí dát slovo, úroveň 1 max. 2 slabiky…), ukládání a převzetí dat z prototypu, rodičovský přehled.
* **End-to-end (73 běhů na 3 velikostech):** všechny lekce správnou i chybovou cestou, zvýšení úrovně po dvou kolech, „Ještě ne“, ťuknutí během řeči, odchod uprostřed lekce, přestávka, výběr kamaráda a rod postavičky, rodičovská brána, nastavení, ochrana proti vložení HTML, export a smazání, offline spuštění, manifest, rozložení (bez posouvání do stran, dotykové cíle ≥ 56 px, popisky tlačítek).

V testech běží časovače 25× rychleji a postavička zapisuje, co řekla (`window.__said`), aby testy nečekaly na řeč a nepřehlédly krátkou větu.

## Struktura

```
src/
  main.ts            obrazovky, domeček, výběr kamaráda
  runtime.ts         stav, řeč, zvuk, čekání na ťuknutí, přerušení lekce
  adaptive.ts        pravidla obtížnosti (čistá funkce)
  czech.ts           čísla slovy, skloňování, rod
  state.ts           tvar dat, výchozí hodnoty, migrace z prototypu
  report.ts          rodičovský přehled a tipy
  parent.ts          brána a rodičovská obrazovka
  characters.ts      postavičky (SVG, hlas, rod)
  content/*.json     obsah lekcí – slova, kroky mytí rukou, úkoly mimo obrazovku
  lessons/*.ts       jednotlivé lekce + společné kroky
tests/unit, tests/e2e
```

**Nové slovo do Orchestru slabik:** přidej řádek do `src/content/words.json`. Test obsahu ohlídá, že slabiky dají dohromady slovo a že na úrovni 1 jsou nejvýš dvě.

## Další fáze

Fáze 2: 12 aktivit ve 4 pokojích (Zahrada emocí), rozšíření slov a posloupností.
Fáze 3: kvalitní český TTS, rozpoznávání řeči s dotykovou zálohou, AI tutor s bezpečnostní vrstvou.
