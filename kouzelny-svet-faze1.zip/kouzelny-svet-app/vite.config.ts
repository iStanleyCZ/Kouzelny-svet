/// <reference types="vitest/config" />
import { defineConfig } from "vite";
import { VitePWA } from "vite-plugin-pwa";
import { viteSingleFile } from "vite-plugin-singlefile";

export default defineConfig(({ mode }) => ({
  base: "./",
  build: { outDir: mode === "single" ? "dist-single" : "dist", emptyOutDir: true },
  plugins:
    mode === "single"
      ? [viteSingleFile()]
      : [
          VitePWA({
            registerType: "autoUpdate",
            injectRegister: "auto",
            includeAssets: ["icon-192.png", "icon-512.png", "apple-touch-icon.png"],
            manifest: {
              name: "Kouzelný svět",
              short_name: "Kouzelný svět",
              description: "Pohádkový učitel pro děti od 4 let",
              lang: "cs",
              start_url: "./",
              display: "standalone",
              orientation: "any",
              background_color: "#F1EAFB",
              theme_color: "#6B3FA8",
              icons: [
                { src: "icon-192.png", sizes: "192x192", type: "image/png" },
                { src: "icon-512.png", sizes: "512x512", type: "image/png" },
                { src: "icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" }
              ]
            },
            workbox: {
              globPatterns: ["**/*.{js,css,html,png,svg,webmanifest}"],
              navigateFallback: "index.html",
              runtimeCaching: [
                {
                  urlPattern: /^https:\/\/fonts\.(googleapis|gstatic)\.com\/.*/,
                  handler: "CacheFirst",
                  options: { cacheName: "fonts", expiration: { maxEntries: 20, maxAgeSeconds: 31536000 } }
                }
              ]
            }
          })
        ],
  test: { include: ["tests/unit/**/*.test.ts"], environment: "node" }
}));
