import wordsJson from "./words.json";
import handwashJson from "./handwash.json";
import offlineJson from "./offline.json";

export interface Word { w: string; s: string[]; e: string }
export interface Step { e: string; t: string }
export interface Choice { e: string; t: string }

export const WORDS: Record<string, Word[]> = wordsJson;
export const HANDWASH: { steps: Record<string, Step>; levels: Record<string, string[]> } = handwashJson;
export const OFFLINE: Record<string, Choice[]> = offlineJson;

/** Content checks. Returns a list of human-readable problems (empty = valid). */
export function validateContent(
  words: Record<string, Word[]> = WORDS,
  handwash = HANDWASH,
  offline: Record<string, Choice[]> = OFFLINE
): string[] {
  const errs: string[] = [];
  const seen = new Set<string>();
  for (const [lvl, list] of Object.entries(words)) {
    if (list.length < 5) errs.push(`slova úroveň ${lvl}: méně než 5 slov`);
    for (const w of list) {
      if (w.s.join("") !== w.w) errs.push(`slovo "${w.w}": slabiky ${w.s.join("-")} nedávají slovo`);
      if (!w.e) errs.push(`slovo "${w.w}": chybí obrázek`);
      if (lvl === "1" && w.s.length > 2) errs.push(`slovo "${w.w}": úroveň 1 má mít nejvýš 2 slabiky`);
      if (w.s.length < 1 || w.s.length > 4) errs.push(`slovo "${w.w}": 1–4 slabiky`);
      if (seen.has(w.w)) errs.push(`slovo "${w.w}" je dvakrát`);
      seen.add(w.w);
    }
  }
  for (const [lvl, ids] of Object.entries(handwash.levels)) {
    for (const id of ids) if (!handwash.steps[id]) errs.push(`mytí rukou úroveň ${lvl}: neznámý krok ${id}`);
    if (new Set(ids).size !== ids.length) errs.push(`mytí rukou úroveň ${lvl}: opakovaný krok`);
  }
  for (const [lesson, list] of Object.entries(offline)) {
    if (list.length !== 3) errs.push(`úkoly mimo obrazovku "${lesson}": mají být 3`);
    for (const c of list) if (!c.e || !c.t) errs.push(`úkol mimo obrazovku "${lesson}": chybí text nebo obrázek`);
  }
  return errs;
}
