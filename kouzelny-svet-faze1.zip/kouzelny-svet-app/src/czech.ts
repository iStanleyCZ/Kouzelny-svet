/** Czech language helpers: number words, plurals, gendered forms. Pure, unit-tested. */

export const NUM_WORDS = ["nula", "jeden", "dva", "tři", "čtyři", "pět", "šest", "sedm", "osm", "devět", "deset"];

const TEENS = ["deset", "jedenáct", "dvanáct", "třináct", "čtrnáct", "patnáct", "šestnáct", "sedmnáct", "osmnáct", "devatenáct"];
const TENS = ["", "", "dvacet", "třicet", "čtyřicet", "padesát", "šedesát", "sedmdesát", "osmdesát", "devadesát"];
const ONES = ["", "jedna", "dva", "tři", "čtyři", "pět", "šest", "sedm", "osm", "devět"];

/** Number 0–99 as it would be read aloud ("dvacet sedm"). */
export function numberWord(n: number): string {
  if (!Number.isInteger(n) || n < 0 || n > 99) throw new RangeError(`numberWord: ${n}`);
  if (n <= 10) return NUM_WORDS[n];
  if (n < 20) return TEENS[n - 10];
  const t = Math.floor(n / 10), o = n % 10;
  return o ? `${TENS[t]} ${ONES[o]}` : TENS[t];
}

/** Czech plural: 1 → one, 2–4 → few, 0 and 5+ → many. */
export function plural(n: number, one: string, few: string, many: string): string {
  if (n === 1) return one;
  if (n >= 2 && n <= 4) return few;
  return many;
}

/** "pro tři medvídky" / "pro pět medvídků" (accusative after "pro"). */
export function bearsAcc(n: number): string {
  return `${n === 1 ? "jednoho" : numberWord(n)} ${plural(n, "medvídka", "medvídky", "medvídků")}`;
}

export function syllableLabel(n: number): string {
  return `${n === 1 ? "Jedna" : n === 2 ? "Dvě" : numberWord(n).replace(/^./, c => c.toUpperCase())} ${plural(n, "slabika", "slabiky", "slabik")}`;
}

/** Pick the feminine or masculine form for the child. */
export const gform = (girl: boolean, f: string, m: string) => (girl ? f : m);
