/** Parent gate and parent overview: a map of what the child does, never a score or diagnosis. */
import { numberWord } from "./czech";
import { summaryBySkill, homeTips } from "./report";
import { defaults, wipe, safeStorage } from "./state";
import { S, save, replaceState, $, voice, stopAll } from "./runtime";

let gateN = 0, gateIn = "";
export function openGate(show: (id: string) => void, onPass: () => void) {
  stopAll(); show("s-gate");
  gateN = 21 + Math.floor(Math.random() * 28); gateIn = "";
  $("gate-word").textContent = numberWord(gateN);
  $("gate-disp").textContent = ""; $("gate-err").textContent = "";
  const kp = $("keypad"); kp.innerHTML = "";
  [1, 2, 3, 4, 5, 6, 7, 8, 9, "⌫", 0, "OK"].forEach(k => {
    const b = document.createElement("button");
    b.textContent = String(k);
    b.setAttribute("aria-label", k === "⌫" ? "smazat číslici" : String(k));
    b.onclick = () => {
      if (k === "⌫") gateIn = gateIn.slice(0, -1);
      else if (k === "OK") {
        if (+gateIn === gateN) { onPass(); return; }
        $("gate-err").textContent = "Číslo nesedí. Zkus to znovu."; gateIn = "";
      } else if (gateIn.length < 3) gateIn += k;
      $("gate-disp").textContent = gateIn;
    };
    kp.appendChild(b);
  });
}

const fmt = (t: number) => new Date(t).toLocaleDateString("cs-CZ", { day: "numeric", month: "numeric" });
const esc = (s: string) => s.replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]!));

export function renderParent(onWiped: () => void) {
  const P = $("parent");
  const rows = summaryBySkill(S);
  const skills = rows.map(r => {
    if (!r.total) return `<div class="skill"><b>${r.label}</b>${r.levelLabel ? `<span class="chip">${r.levelLabel}</span>` : ""}<p class="legend">Zatím nevyzkoušeno.</p></div>`;
    return `<div class="skill"><b>${r.label}</b>${r.levelLabel ? `<span class="chip">${r.levelLabel}</span>` : ""}
      <div class="bar"><i style="width:${(r.sama / r.total) * 100}%;background:var(--mint)"></i><i style="width:${(r.napoveda / r.total) * 100}%;background:var(--gold)"></i><i style="width:${(r.ukazka / r.total) * 100}%;background:var(--berry)"></i></div>
      <p class="legend">${r.sama}× samostatně · ${r.napoveda}× s nápovědou · ${r.ukazka}× s ukázkou · naposledy ${fmt(r.last)}</p></div>`;
  }).join("");
  const strat: Record<string, number> = {};
  S.strategies.forEach(s => (strat[s.s] = (strat[s.s] || 0) + 1));
  const voiceTxt = voice
    ? `Český hlas nalezen (${esc(voice.name)}).`
    : "Český hlas v zařízení nenalezen, postavička mluví jen titulky. Na iPadu: Nastavení › Zpřístupnění › Předčítaný obsah › Hlasy › Čeština.";
  P.innerHTML = `
  <div class="panel"><h3>Co se dítě učí</h3><div class="skills">${skills}</div>
   <p class="legend" style="margin-top:8px">Zelená: zvládlo samo · žlutá: s nápovědou · růžová: s ukázkou postavičky. Nejde o hodnocení ani diagnózu, jen o mapu, kde dítě potřebuje podporu.</p></div>
  <div class="panel"><h3>Zkuste spolu doma</h3><ul>${homeTips(S).map(t => `<li>${t}</li>`).join("")}</ul></div>
  <div class="panel"><h3>Jak přemýšlí</h3>${Object.keys(strat).length ? Object.entries(strat).map(([s, n]) => `<span class="chip">${esc(s)} · ${n}×</span>`).join("") : "<p class='legend'>Strategie se objeví po první lekci.</p>"}
   <h3 style="margin-top:14px">Na co bylo pyšné</h3>${S.proud.slice(-6).reverse().map(p => `<span class="chip">${fmt(p.t)} · ${esc(p.a)}</span>`).join("") || "<p class='legend'>Zatím nic.</p>"}
   <h3 style="margin-top:14px">Vybrané úkoly mimo obrazovku</h3>${S.offline.slice(-6).reverse().map(o => `<p>${fmt(o.t)} – ${esc(o.task)}</p>`).join("") || "<p class='legend'>Zatím nic.</p>"}</div>
  <div class="panel"><h3>Galerie kreseb</h3><div class="gallery">${S.gallery.map(x => `<img src="${x.img}" alt="Kresba z ${fmt(x.t)}">`).join("") || "<p class='legend'>Zatím žádná kresba.</p>"}</div></div>
  <div class="panel"><h3>Nastavení</h3>
   <div class="set"><label for="nm">Jméno dítěte</label><input type="text" id="nm" maxlength="20" value="${esc(S.name)}" placeholder="nepovinné"><button class="small-btn" id="nm-save">Uložit</button></div>
   <div class="set"><label>Oslovení</label><span class="seg"><button data-g="1" class="${S.girl ? "on" : ""}">holčička</button><button data-g="0" class="${S.girl ? "" : "on"}">kluk</button></span></div>
   <div class="set"><label>Délka hraní</label><span class="seg">${[5, 10, 15, 20].map(m => `<button data-m="${m}" class="${S.limitMin === m ? "on" : ""}">${m} min</button>`).join("")}</span></div>
   <div class="set"><label>Rychlost řeči</label><span class="seg">${([[0.8, "pomalu"], [0.92, "normálně"], [1.05, "rychleji"]] as const).map(([v, t]) => `<button data-r="${v}" class="${Math.abs(S.rate - v) < 0.01 ? "on" : ""}">${t}</button>`).join("")}</span></div>
   <p class="note">${voiceTxt}</p></div>
  <div class="panel"><h3>Data a soukromí</h3>
   <p class="note">Vše je uložené jen v tomto zařízení. Nic se neodesílá, mikrofon se nepoužívá, nahrávky neexistují. Aplikace funguje i bez internetu.</p>
   <div class="set"><button class="small-btn ghost" id="exp">Zobrazit data (JSON)</button><button class="small-btn danger" id="del">Smazat všechna data</button></div>
   <div id="exp-box" hidden><textarea id="exp-ta" readonly aria-label="Data aplikace"></textarea><button class="small-btn" id="copy" style="margin-top:8px">Kopírovat</button></div>
   <div id="del-box" hidden class="set"><span style="font-weight:800">Opravdu smazat pokrok, kresby a nastavení?</span><button class="small-btn danger" id="del-yes">Ano, smazat</button><button class="small-btn ghost" id="del-no">Ne</button></div></div>`;
  const rerender = () => renderParent(onWiped);
  $("nm-save").onclick = () => { S.name = ($("nm") as HTMLInputElement).value.trim().slice(0, 20); save(); $("nm-save").textContent = "Uloženo"; };
  P.querySelectorAll<HTMLElement>("[data-g]").forEach(b => (b.onclick = () => { S.girl = b.dataset.g === "1"; save(); rerender(); }));
  P.querySelectorAll<HTMLElement>("[data-m]").forEach(b => (b.onclick = () => { S.limitMin = +b.dataset.m!; save(); rerender(); }));
  P.querySelectorAll<HTMLElement>("[data-r]").forEach(b => (b.onclick = () => { S.rate = +b.dataset.r!; save(); rerender(); }));
  $("exp").onclick = () => {
    ($("exp-ta") as HTMLTextAreaElement).value = JSON.stringify({ ...S, gallery: `${S.gallery.length} kreseb` }, null, 2);
    $("exp-box").hidden = false;
  };
  $("copy").onclick = () => {
    const ta = $("exp-ta") as HTMLTextAreaElement;
    (navigator.clipboard?.writeText(ta.value) ?? Promise.reject()).then(() => ($("copy").textContent = "Zkopírováno")).catch(() => ta.select());
  };
  $("del").onclick = () => ($("del-box").hidden = false);
  $("del-no").onclick = () => ($("del-box").hidden = true);
  $("del-yes").onclick = () => { wipe(safeStorage()); replaceState(defaults()); wipe(safeStorage()); onWiped(); };
}
