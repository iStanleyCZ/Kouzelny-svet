import "./styles.css";
import { CH } from "./characters";
import type { AssistantId } from "./state";
import { S, save, $, mount, target, sayFree, stopAll, audio, lastText, skipSpeech, installTapCapture, isAbort } from "./runtime";
import { run as kolacek } from "./lessons/kolacek";
import { run as slabiky } from "./lessons/slabiky";
import { run as ruce } from "./lessons/ruce";
import { openGate, renderParent } from "./parent";

interface Room { k: string; cls: string; pic: string; t: string; s: string; run?: () => Promise<string> }
export const ROOMS: Room[] = [
  { k: "kolacek", cls: "r1", pic: "🧁", t: "Ostrov čísel", s: "Ztracený koláček", run: kolacek },
  { k: "slabiky", cls: "r2", pic: "🥁", t: "Les slov", s: "Orchestr slabik", run: slabiky },
  { k: "emoce", cls: "r3 locked", pic: "🌷", t: "Zahrada emocí", s: "Jak se dnes cítíš?" },
  { k: "ruce", cls: "r4", pic: "🧼", t: "Dům samostatnosti", s: "Mytí rukou", run: ruce }
];

let sessionStart = Date.now();
function show(id: string) { document.querySelectorAll<HTMLElement>(".screen").forEach(s => (s.hidden = s.id !== id)); }

function goHouse(greet = true) {
  stopAll();
  if ((Date.now() - sessionStart) / 60000 >= S.limitMin) {
    show("s-break"); mount($("break-ch")); target($("break-ch"), null);
    sayFree("Dnes jsme toho stihli hodně. Dáme si pauzu. Protáhni se jako kočička!");
    return;
  }
  show("s-house"); mount($("house-ch")); target($("house-ch"), $("house-bubble"));
  $("house-title").textContent = S.name ? `Domeček – ${S.name}` : "Domeček";
  const box = $("rooms"); box.innerHTML = "";
  for (const r of ROOMS) {
    const b = document.createElement("button");
    b.className = "room " + r.cls; b.id = "room-" + r.k;
    const stars = S.stars[r.k] ? `<span class="stars" aria-label="${S.stars[r.k]} hvězd">${"★".repeat(Math.min(5, S.stars[r.k]))}</span>` : "";
    b.innerHTML = `<span class="pic" aria-hidden="true">${r.pic}</span><span><b>${r.t}</b><br><small>${r.s}</small></span>${r.run ? stars : '<span class="badge">Brzy</span>'}`;
    b.onclick = () => {
      audio();
      if (r.run) startLesson(r);
      else { stopAll(); sayFree(`Sem se podíváme brzy. Teď zkus jiný pokojík.`); }
    };
    box.appendChild(b);
  }
  if (greet) {
    const h = new Date().getHours();
    const hi = h < 10 ? "Dobré ráno" : h < 18 ? "Ahoj" : "Dobrý večer";
    sayFree(`${hi}${S.name ? ", " + S.name : ""}! Kam se dnes vydáme? Ťukni na pokojík.`);
  }
}

function startLesson(r: Room) {
  stopAll(); show("s-lesson");
  $("lesson-title").textContent = r.s;
  mount($("lesson-ch")); target($("lesson-ch"), $("lesson-bubble"));
  $("stage").innerHTML = "";
  r.run!().then(res => {
    if (res === "done") { S.stars[r.k] = (S.stars[r.k] || 0) + 1; save(); }
    goHouse(false);
    sayFree(res === "done" ? "Jsem zpátky v domečku. Kam dál?" : "Kam se podíváme?");
  }).catch(e => { if (!isAbort(e)) { console.error(e); goHouse(false); } });
}

let picked: AssistantId | null = null;
function openPick() {
  stopAll(); show("s-pick"); target(null, null);
  const box = $("pick"); box.innerHTML = ""; picked = S.assistant;
  (Object.keys(CH) as AssistantId[]).forEach(k => {
    const c = CH[k];
    const b = document.createElement("button");
    b.className = "pick-card" + (k === picked ? " on" : ""); b.id = "pick-" + k;
    b.innerHTML = `<div class="ch-wrap"></div><b>${c.full}</b><small>${c.tag}</small>`;
    box.appendChild(b); mount(b.querySelector(".ch-wrap")!, k);
    b.onclick = () => {
      audio(); picked = k;
      document.querySelectorAll(".pick-card").forEach(x => x.classList.remove("on")); b.classList.add("on");
      const pb = $<HTMLButtonElement>("b-pick"); pb.disabled = false; pb.style.opacity = "1";
      stopAll(); target(b.querySelector(".ch-wrap"), null);
      const prev = S.assistant; S.assistant = k; sayFree(`Ahoj, já jsem ${c.full}. ${c.hi}.`); S.assistant = prev;
    };
  });
  const pb = $<HTMLButtonElement>("b-pick"); pb.disabled = !picked; pb.style.opacity = picked ? "1" : ".4";
}

function boot() {
  installTapCapture($("stage"));
  mount($("start-ch"), "fousek");
  $("b-start").onclick = () => { audio(); sessionStart = Date.now(); if (S.assistant) goHouse(); else openPick(); };
  $("b-pick").onclick = () => { if (!picked) return; S.assistant = picked; save(); goHouse(); };
  $("b-friend").onclick = () => { audio(); openPick(); };
  $("b-home").onclick = () => goHouse(false);
  $("b-repeat").onclick = () => { audio(); if (lastText) { skipSpeech(); sayFree(lastText); } };
  $("b-break").onclick = () => { sessionStart = Date.now(); goHouse(); };
  const toParent = () => { show("s-parent"); renderParent(() => { stopAll(); show("s-start"); }); };
  $("b-parent").onclick = () => openGate(show, toParent);
  $("b-gate-back").onclick = () => goHouse(false);
  $("b-parent-back").onclick = () => goHouse(false);
}
boot();
