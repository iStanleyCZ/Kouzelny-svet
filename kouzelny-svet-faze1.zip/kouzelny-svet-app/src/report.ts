/** Parent report: pure functions over the state, unit-tested. No scores, no diagnoses. */
import type { AppState, LogSkill } from "./state";

export const SKILL_LABEL: Record<LogSkill, string> = {
  pojmenovani: "Pojmenování předmětů",
  pocitani: "Množství a počítání",
  slabiky: "Slabiky a rytmus",
  posloupnost: "Posloupnost (mytí rukou)",
  pozornost: "Pozornost a hledání"
};

const LEVEL_LABEL: Partial<Record<LogSkill, Record<number, string>>> = {
  pocitani: { 1: "úroveň do 3", 2: "úroveň do 5" },
  slabiky: { 1: "krátká slova", 2: "delší slova" },
  posloupnost: { 1: "4 kroky", 2: "6 kroků" }
};

export interface SkillRow { skill: LogSkill; label: string; levelLabel: string; sama: number; napoveda: number; ukazka: number; total: number; last: number; supportShare: number }

export function summaryBySkill(s: AppState): SkillRow[] {
  return (Object.keys(SKILL_LABEL) as LogSkill[]).map(skill => {
    const items = s.log.filter(l => l.skill === skill);
    const sama = items.filter(l => l.res === "sama").length;
    const napoveda = items.filter(l => l.res === "napoveda").length;
    const ukazka = items.filter(l => l.res === "ukazka").length;
    const total = items.length;
    const lvl = skill in s.progress ? (s.progress as Record<string, { level: number }>)[skill].level : 0;
    return {
      skill, label: SKILL_LABEL[skill], levelLabel: LEVEL_LABEL[skill]?.[lvl] ?? "",
      sama, napoveda, ukazka, total,
      last: items.reduce((m, l) => Math.max(m, l.t), 0),
      supportShare: total ? (napoveda + ukazka) / total : 0
    };
  });
}

/** Suggestions for joint offline play, driven by where the child needs support. */
export function homeTips(s: AppState): string[] {
  const rows = Object.fromEntries(summaryBySkill(s).map(r => [r.skill, r]));
  const tips: string[] = [];
  const needs = (k: LogSkill) => rows[k].total >= 2 && rows[k].supportShare > 0.4;
  const fine = (k: LogSkill) => rows[k].total >= 2 && rows[k].supportShare <= 0.4;
  if (needs("slabiky")) tips.push("Vytleskávejte spolu jména a slova při procházce nebo vaření. Rytmus pomáhá víc než opakování na tabletu.");
  else if (fine("slabiky")) tips.push("Slabiky jdou dobře. Zkuste hru: kdo najde slovo se třemi slabikami?");
  if (needs("pocitani")) tips.push("Při prostírání nechte dítě dát každému talíř a pak se zeptejte, kolik ještě chybí.");
  else if (fine("pocitani")) tips.push("Malá množství zvládá samostatně. Zkoušejte rozdělovat ovoce mezi plyšáky.");
  if (needs("posloupnost")) tips.push("Při mytí rukou nahlas pojmenovávejte kroky: nejdřív, potom, nakonec.");
  else if (fine("posloupnost")) tips.push("Pořadí kroků zvládá. Nechte dítě vysvětlit plyšákovi, jak se oblékáme ven.");
  if (!tips.length) tips.push("Zahrajte si spolu některé dobrodružství, pak tu uvidíte první doporučení.");
  return tips;
}
