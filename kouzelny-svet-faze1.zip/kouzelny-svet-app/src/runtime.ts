/**
 * Runtime shared by all lessons: state singleton, speech, sound, waiting for taps,
 * cancelling a lesson when the child leaves.
 */
import { CH } from "./characters";
import { addLog, load, safeStorage, save as saveState, type AppState, type LogSkill } from "./state";
import type { Outcome } from "./adaptive";
import { gform } from "./czech";

/* ---------- state ---------- */
const store = safeStorage();
export let S: AppState = load(store);
export const save = () => saveState(store, S);
export const replaceState = (s: AppState) => { S = s; save(); };
export const g = (f: string, m: string) => gform(S.girl, f, m);
export const C = () => CH[S.assistant ?? "fousek"];
/** Character's own gendered form ("schovala" / "schoval"). */
export const cg = (f: string, m: string) => (C().fem ? f : m);
export function log(lesson: string, skill: LogSkill, res: Outcome, d: string) {
  addLog(S, { t: Date.now(), lesson, skill, res, d });
  save();
}

/* ---------- helpers ---------- */
export const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
export const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms));
export function shuffle<T>(a: T[]): T[] {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
export function mount(el: HTMLElement, key = S.assistant ?? "fousek") { el.innerHTML = CH[key].svg(); }

/* ---------- sound ---------- */
let AC: AudioContext | null = null;
export function audio() {
  if (!AC) { try { AC = new (window.AudioContext || (window as any).webkitAudioContext)(); } catch { /* no audio */ } }
  if (AC && AC.state === "suspended") void AC.resume();
}
export function tone(f: number, d = 0.28, type: OscillatorType = "triangle", v = 0.18) {
  if (!AC) return;
  const o = AC.createOscillator(), gn = AC.createGain();
  o.type = type; o.frequency.value = f;
  gn.gain.setValueAtTime(v, AC.currentTime);
  gn.gain.exponentialRampToValueAtTime(0.001, AC.currentTime + d);
  o.connect(gn).connect(AC.destination); o.start(); o.stop(AC.currentTime + d);
}
export const SCALE = [523, 587, 659, 698, 784, 880, 988, 1047];
export async function melody() { for (const f of [523, 659, 784, 1047, 784, 1047]) { tone(f, 0.22); await sleep(150); } }
export const boop = () => tone(330, 0.18, "sine", 0.12);

/* ---------- lesson cancellation ---------- */
export const ABORT = { abort: true } as const;
let T = 0;
export const token = () => T;
export const isAbort = (e: unknown) => e === ABORT;

/* ---------- speech ---------- */
export let voice: SpeechSynthesisVoice | null = null;
function pickVoice() { if (!("speechSynthesis" in window)) return; voice = speechSynthesis.getVoices().find(v => /^cs/i.test(v.lang)) ?? null; }
if (typeof window !== "undefined" && "speechSynthesis" in window) { pickVoice(); speechSynthesis.onvoiceschanged = pickVoice; }

let curBubble: HTMLElement | null = null, curWrap: HTMLElement | null = null, curFin: (() => void) | null = null;
export let lastText = "";
export function target(wrap: HTMLElement | null, bubble: HTMLElement | null) { curWrap = wrap; curBubble = bubble; }
export function setMood(m: "happy" | "thinking" | null) {
  if (!curWrap) return;
  curWrap.classList.remove("happy", "thinking");
  if (m) { void curWrap.offsetWidth; curWrap.classList.add(m); }
}
export const speaking = () => !!curFin;
export function skipSpeech() {
  if (!curFin) return;
  try { speechSynthesis.cancel(); } catch { /* ignore */ }
  const f = curFin; curFin = null; f();
}
/** Speak a line (Czech voice if the device has one), always shown as a subtitle. Rejects with ABORT if the lesson was left. */
export function say(text: string): Promise<void> {
  const tok = T; lastText = text;
  // test hook: e2e tests read the transcript instead of racing the subtitle
  const said = (window as any).__said as string[] | undefined;
  if (said) said.push(text);
  return new Promise<void>(res => {
    if (curBubble) curBubble.textContent = text;
    curWrap?.classList.add("speaking");
    let done = false;
    const fin = () => {
      if (done) return; done = true;
      if (curFin === fin) curFin = null;
      curWrap?.classList.remove("speaking"); res();
    };
    curFin = fin;
    const est = Math.max(1100, (text.length * 72) / S.rate);
    if (voice && "speechSynthesis" in window) {
      try {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = "cs-CZ"; u.voice = voice; u.rate = S.rate; u.pitch = C().pitch;
        u.onend = fin; u.onerror = fin;
        speechSynthesis.speak(u);
        setTimeout(fin, est * 1.6 + 2500);
      } catch { setTimeout(fin, est); }
    } else setTimeout(fin, est);
  }).then(() => { if (tok !== T) throw ABORT; });
}
/** Fire-and-forget speech outside a lesson flow. */
export const sayFree = (text: string) => { say(text).catch(() => {}); };

export function stopAll() {
  T++;
  skipSpeech();
  try { speechSynthesis.cancel(); } catch { /* ignore */ }
  curWrap?.classList.remove("speaking", "happy", "thinking");
}

/* ---------- waiting for taps ---------- */
type Tappable = HTMLElement & { _pre?: boolean; _waiting?: boolean; _h?: () => void };
/**
 * Resolve with whichever element the child taps. A tap made while the character
 * was still talking (before anyone listened) counts too.
 */
export function waitFor(input: HTMLElement | HTMLElement[] | null): Promise<HTMLElement> {
  const tok = T;
  const els = ([] as (HTMLElement | null)[]).concat(input).filter(Boolean) as Tappable[];
  return new Promise<HTMLElement>(res => {
    const finish = (el: Tappable) => {
      els.forEach(e => { e._pre = false; e._waiting = false; if (e._h) e.removeEventListener("click", e._h); });
      res(el);
    };
    const pre = els.find(e => e._pre);
    if (pre) { finish(pre); return; }
    els.forEach(el => { el._waiting = true; el._h = () => { audio(); finish(el); }; el.addEventListener("click", el._h); });
  }).then(v => { if (tok !== T) throw ABORT; return v; });
}
/** Install once: a tap inside the activity area cuts speech short and is remembered. */
export function installTapCapture(stageEl: HTMLElement) {
  stageEl.addEventListener("click", e => {
    const b = (e.target as HTMLElement).closest("button") as Tappable | null;
    if (!b) return;
    if (!b._waiting && !(b as HTMLButtonElement).disabled) b._pre = true;
    skipSpeech();
  }, true);
}

/* ---------- stage ---------- */
export const stage = () => $("stage");
export function html(h: string) { stage().innerHTML = h; return stage(); }
export const q = <T extends HTMLElement = HTMLElement>(s: string) => stage().querySelector(s) as T;
export const qa = <T extends HTMLElement = HTMLElement>(s: string) => [...stage().querySelectorAll(s)] as T[];
export const disable = (sel: string, on = true) => qa<HTMLButtonElement>(sel).forEach(b => (b.disabled = on));
