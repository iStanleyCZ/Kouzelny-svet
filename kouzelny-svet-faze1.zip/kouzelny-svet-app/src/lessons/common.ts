/** Steps shared by lessons: home task, self-reflection, "how did you know", drawing. */
import { OFFLINE, type Choice } from "../content";
import { S, save, say, setMood, waitFor, html, q, qa, g, tone, boop } from "../runtime";

const opts = (list: Choice[]) =>
  `<div class="row">${list.map((o, i) => `<button class="opt" data-i="${i}"><span class="e">${o.e}</span>${o.t}</button>`).join("")}</div>`;

/** Choose one task to do away from the screen (Montessori: back to real life). */
export async function offlineChoice(lesson: string) {
  const list = OFFLINE[lesson];
  html(opts(list));
  await say("Ještě jeden úkol, tentokrát doma, bez tabletu. Vyber si: " + list.map(o => o.t).join(", nebo ") + ".");
  const el = await waitFor(qa(".opt"));
  const o = list[+el.dataset.i!];
  S.offline.push({ t: Date.now(), lesson, task: o.t }); save();
  html(`<div class="pic-word">${o.e}</div>`);
  setMood("happy");
  await say(`Super volba! ${o.t}. Pak to řekni mámě nebo tátovi.`);
}

/** Self-assessment instead of praise from the app. */
export async function reflect(lesson: string, list: Choice[]) {
  html(opts(list));
  await say(`Na co jsi dnes ${g("pyšná", "pyšný")}?`);
  const el = await waitFor(qa(".opt"));
  S.proud.push({ t: Date.now(), lesson, a: list[+el.dataset.i!].t }); save();
  setMood("happy");
  await say(`To je pěkné. Můžeš na to být ${g("pyšná", "pyšný")}.`);
}

/** Feuerstein: name the strategy. Every answer is accepted and gets specific feedback. */
export async function howDidYouKnow(question: string, list: (Choice & { key: string; fb: string })[]) {
  await say(question);
  html(opts(list));
  const el = await waitFor(qa(".opt"));
  const c = list[+el.dataset.i!];
  S.strategies.push({ t: Date.now(), s: c.key }); save();
  setMood("happy");
  await say(c.fb);
}

/** Finger painting; keeps a small thumbnail for the parent gallery. */
export async function drawPicture(prompt: string, praise: string) {
  const stageW = (document.getElementById("stage")?.clientWidth ?? 400) - 8;
  const w = Math.max(240, Math.min(520, stageW)), h = Math.round(w * 0.7);
  const cols: [string, string][] = [["#8E5CC9", "fialová"], ["#E77BAE", "růžová"], ["#F2B83A", "žlutá"], ["#9A6232", "hnědá"], ["#5FC3A6", "zelená"]];
  html(`<canvas id="cv" width="${w * 2}" height="${h * 2}" style="width:${w}px;height:${h}px"></canvas>
    <div class="palette">${cols.map((c, i) => `<button class="sw${i === 0 ? " on" : ""}" data-c="${c[0]}" style="background:${c[0]}" aria-label="${c[1]}"></button>`).join("")}</div>
    <div class="row"><button class="big soft" id="clr">Smazat</button><button class="big" id="done">Hotovo</button></div>`);
  const cv = q<HTMLCanvasElement>("#cv"), x = cv.getContext("2d")!;
  x.scale(2, 2);
  const base = () => {
    x.fillStyle = "#fff"; x.fillRect(0, 0, w, h);
    x.strokeStyle = "#E2D3F7"; x.lineWidth = 6; x.beginPath(); x.ellipse(w / 2, h * 0.72, w * 0.38, h * 0.12, 0, 0, Math.PI * 2); x.stroke();
    x.lineCap = x.lineJoin = "round"; x.lineWidth = Math.max(10, w / 30);
  };
  base();
  let col = cols[0][0], down = false, lx = 0, ly = 0;
  qa(".sw").forEach(s => (s.onclick = () => { qa(".sw").forEach(o => o.classList.remove("on")); s.classList.add("on"); col = s.dataset.c!; tone(660, 0.1); }));
  const pos = (e: PointerEvent) => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * w / r.width, (e.clientY - r.top) * h / r.height]; };
  cv.addEventListener("pointerdown", e => { down = true; [lx, ly] = pos(e); try { cv.setPointerCapture(e.pointerId); } catch { /* ignore */ } x.fillStyle = col; x.beginPath(); x.arc(lx, ly, x.lineWidth / 2, 0, 7); x.fill(); });
  cv.addEventListener("pointermove", e => { if (!down) return; const [nx, ny] = pos(e); x.strokeStyle = col; x.beginPath(); x.moveTo(lx, ly); x.lineTo(nx, ny); x.stroke(); lx = nx; ly = ny; });
  ["pointerup", "pointercancel"].forEach(t => cv.addEventListener(t, () => (down = false)));
  q("#clr").onclick = () => { base(); boop(); };
  await say(prompt);
  await waitFor(q("#done"));
  try {
    const t = document.createElement("canvas"); t.width = 240; t.height = 168;
    t.getContext("2d")!.drawImage(cv, 0, 0, 240, 168);
    S.gallery.unshift({ t: Date.now(), img: t.toDataURL("image/jpeg", 0.6) });
    S.gallery = S.gallery.slice(0, 8); save();
  } catch { /* storage full: drawing just isn't kept */ }
  setMood("happy");
  await say(praise);
}
