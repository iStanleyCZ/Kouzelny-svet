/**
 * Les slov – „Orchestr slabik“ (Elkonin step 2: rhythm and syllables).
 * The child taps the drum once per syllable. The syllables stay hidden until the answer
 * is evaluated, so the screen never gives the count away.
 */
import { WORDS, type Word } from "../content";
import { nextProgress, outcomeFromMistakes, type Outcome } from "../adaptive";
import { syllableLabel } from "../czech";
import { MAX_LEVEL } from "../state";
import { S, save, log, say, sayFree, setMood, waitFor, html, q, qa, disable, g, tone, boop, melody, audio, shuffle, SCALE } from "../runtime";
import { offlineChoice, reflect } from "./common";

export const ROUND = 5;
const CONTROLS = "#drum,#ok,#slow,#again";
const orchestra = `<div class="orch play"><span>🐻</span><span>🐰</span><span>🦊</span><span>🐸</span></div>`;

export async function run(): Promise<"done"> {
  const lv = S.progress.slabiky.level;
  const list: Word[] = shuffle(WORDS[String(lv)]).slice(0, ROUND);
  const outcomes: Outcome[] = [];

  html(orchestra);
  setMood("happy"); void melody();
  await say("Vítej v mém orchestru! Já říkám slovo a ty ťukáš taktovkou na buben. Jedno ťuknutí za každou slabiku. Třeba má-ma, to jsou dvě ťuknutí.");

  for (const W of list) {
    let attempt = 0;
    for (;;) {
      html(`<div class="pic-word" data-syl="${W.s.length}">${W.e}</div>
        <div class="syl" id="syl">${attempt >= 2 ? W.s.map(s => `<span class="lit">${s}</span>`).join("") : ""}</div>
        <div class="notes" id="notes"></div>
        <div class="row" style="align-items:center"><button class="big soft" id="slow">Pomalu</button><button class="drum" id="drum" aria-label="buben">ťuk</button><button class="big" id="ok">Hotovo</button></div>
        <button class="small-btn ghost" id="again" style="font-size:17px">Začít znovu</button>`);
      let n = 0;
      const notes = q("#notes"), drum = q("#drum");
      drum.onclick = () => {
        audio();
        if (n >= 6) return;
        tone(SCALE[n]); n++;
        notes.insertAdjacentHTML("beforeend", "<i></i>");
        drum.classList.add("pop"); setTimeout(() => drum.classList.remove("pop"), 300);
      };
      q("#again").onclick = () => { n = 0; notes.innerHTML = ""; boop(); };
      q("#slow").onclick = () => sayFree(W.s.join(", "));
      if (attempt === 0) await say(`Tohle je ${W.w}. ${W.w}. Kolikrát ťukneš?`);
      for (;;) { await waitFor(q("#ok")); if (n > 0) break; await say("Nejdřív ťukni na buben."); }

      if (n === W.s.length) {
        disable(CONTROLS);
        q("#syl").innerHTML = W.s.map(s => `<span class="lit">${s}</span>`).join("");
        setMood("happy"); void melody();
        const res = outcomeFromMistakes(attempt);
        outcomes.push(res);
        log("slabiky", "slabiky", res, `${W.w}: ${W.s.length} slab., pokus ${attempt + 1}`);
        await say(`${W.s.join("-")}! ${syllableLabel(W.s.length)}. Orchestr hraje pro tebe!`);
        break;
      }
      attempt++; boop(); disable(CONTROLS);
      if (attempt === 1) {
        setMood("thinking");
        await say("Skoro. Poslouchej pozorně a tleskej se mnou.");
        q("#syl").innerHTML = W.s.map(() => "<span></span>").join("");
        const sp = qa("#syl span");
        for (let i = 0; i < W.s.length; i++) { sp[i].textContent = W.s[i]; sp[i].classList.add("lit"); tone(SCALE[i]); await say(W.s[i]); }
        await say("Teď to zkus ty.");
      } else {
        setMood(null);
        await say(`Já to taky někdy popletu. Ťukneme to spolu: ${W.s.join(", ")}. Ťukni tolikrát, kolik svítí kousků.`);
      }
    }
  }

  const before = S.progress.slabiky.level;
  S.progress.slabiky = nextProgress(S.progress.slabiky, outcomes, MAX_LEVEL.slabiky); save();
  const independent = outcomes.filter(o => o === "sama").length;
  html(orchestra); void melody();
  await say(independent >= 4
    ? "Tvoje ťukání je přesné jako u opravdového bubeníka!"
    : `Dnes jsi ${g("ťukala", "ťukal")} moc pěkně. A každým dnem to půjde líp.`);
  if (S.progress.slabiky.level > before) await say("Příště ti zahraju delší slova.");

  await offlineChoice("slabiky");
  await reflect("slabiky", [
    { e: "🥁", t: `Ťukal${g("a", "")} jsem do rytmu` },
    { e: "👂", t: `Poslouchal${g("a", "")} jsem pozorně` },
    { e: "🔁", t: `Nevzdal${g("a", "")} jsem to` }
  ]);
  return "done";
}
