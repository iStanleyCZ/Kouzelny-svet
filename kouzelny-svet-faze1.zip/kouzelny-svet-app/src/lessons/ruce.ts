/**
 * Dům samostatnosti – „Mytí rukou“.
 * Feuerstein: sequencing and planning; Montessori: practical life, then done for real at home.
 * Each step has its own hint ladder: hint question → highlighted card → modelled step.
 */
import { HANDWASH } from "../content";
import { nextProgress, outcomeFromMistakes, type Outcome } from "../adaptive";
import { NUM_WORDS } from "../czech";
import { MAX_LEVEL } from "../state";
import { S, save, log, say, sayFree, setMood, waitFor, html, q, qa, g, tone, boop, melody, shuffle, SCALE } from "../runtime";
import { offlineChoice, reflect, howDidYouKnow } from "./common";

export const BUBBLES = 10;

/** Shuffle that never returns the solved order (a child shouldn't get a free pass). */
export function scramble<T>(a: T[], rnd: (x: T[]) => T[] = shuffle): T[] {
  if (a.length < 2) return a.slice();
  for (let i = 0; i < 20; i++) { const s = rnd(a); if (s.some((v, k) => v !== a[k])) return s; }
  return [...a.slice(1), a[0]];
}

export async function run(): Promise<"done"> {
  const lv = S.progress.posloupnost.level;
  const order = HANDWASH.levels[String(lv)];
  const step = (id: string) => HANDWASH.steps[id];

  html(`<div class="pic-word">🧼</div>`);
  setMood("happy");
  await say("Než budeme jíst, umyjeme si ruce. Ale popletly se mi obrázky. Pomůžeš mi je seřadit?");

  html(`<div class="slots${order.length > 4 ? " six" : ""}" id="slots">${order.map((_, i) => `<div class="slot" id="s${i}"><span class="n">${i + 1}</span></div>`).join("")}</div>
    <div class="cards" id="cards">${scramble(order).map(id => `<button class="card" data-id="${id}" aria-label="${step(id).t}"><span class="e">${step(id).e}</span>${step(id).t}</button>`).join("")}</div>`);
  await say("Co uděláme úplně první? Ťukni na obrázek.");

  const outcomes: Outcome[] = [];
  for (let i = 0; i < order.length; i++) {
    const want = order[i];
    let wrong = 0;
    for (;;) {
      const c = await waitFor(qa(".card:not(.used)"));
      if (c.dataset.id === want) break;
      wrong++; boop();
      if (wrong === 1) {
        setMood("thinking");
        await say(i === 0 ? "Hmm, to by ještě nešlo. Co musíme udělat úplně nejdřív?" : `Hmm. Už máme: ${step(order[i - 1]).t.toLowerCase()}. Co přijde potom?`);
      } else {
        q(`.card[data-id="${want}"]`).classList.add("hint");
        setMood(null);
        await say(`Já se taky někdy spletu. Myslím, že teď přijde tohle: ${step(want).t.toLowerCase()}. Vidíš, jak svítí?`);
      }
    }
    const card = q(`.card[data-id="${want}"]`);
    card.classList.remove("hint"); card.classList.add("used");
    const slot = q(`#s${i}`);
    slot.classList.add("filled");
    slot.insertAdjacentHTML("beforeend", `<span class="pop">${step(want).e}</span>`);
    tone(SCALE[Math.min(i, SCALE.length - 1)]);
    const res = outcomeFromMistakes(wrong);
    outcomes.push(res);
    await say(step(want).t + ".");
  }
  log("ruce", "posloupnost", outcomes.every(o => o === "sama") ? "sama" : outcomes.includes("ukazka") ? "ukazka" : "napoveda",
    `${order.length} kroků, samostatně ${outcomes.filter(o => o === "sama").length}`);
  const before = S.progress.posloupnost.level;
  S.progress.posloupnost = nextProgress(S.progress.posloupnost, outcomes, MAX_LEVEL.posloupnost); save();
  setMood("happy"); void melody();
  await say("Hotovo! Takhle se myjí ruce.");

  if (outcomes.every(o => o === "sama")) {
    await howDidYouKnow(`Jak jsi ${g("věděla", "věděl")}, co přijde dřív?`, [
      { e: "🏠", t: "Takhle to dělám doma", key: "zná to z domova", fb: "Výborně, to, co děláš doma, ti pomohlo i tady." },
      { e: "🤔", t: `Přemýšlel${g("a", "")} jsem, co dává smysl`, key: "přemýšlel(a), co dává smysl", fb: "Přemýšlet, co musí být dřív, je chytrý způsob." },
      { e: "🔁", t: `Zkoušel${g("a", "")} jsem to`, key: "zkoušel(a)", fb: "Zkoušet a hledat je taky dobrá cesta." }
    ]);
  }
  if (S.progress.posloupnost.level > before) await say("Příště to zkusíme i s kohoutkem a třením, pěkně krok za krokem.");

  // bubbles: fine motor + counting to ten
  const pos: [number, number][] = [];
  for (let i = 0; i < BUBBLES; i++) pos.push([5 + (i % 5) * 19 + Math.random() * 6, 6 + Math.floor(i / 5) * 46 + Math.random() * 20]);
  html(`<div class="count-big" id="cnt"></div><div class="foam">${pos.map(([x, y], i) =>
    `<button class="bub" data-i="${i}" aria-label="bublina" style="left:${x}%;top:${y}%"></button>`).join("")}</div>`);
  await say("Při mytí se dělají bublinky. Ťukej na ně, já budu počítat.");
  for (let k = 1; k <= BUBBLES; k++) {
    const b = await waitFor(qa(".bub:not(.popped)"));
    b.classList.add("popped"); (b as HTMLButtonElement).disabled = true;
    tone(SCALE[(k - 1) % SCALE.length]);
    q("#cnt").textContent = String(k);
    sayFree(NUM_WORDS[k]);
  }
  setMood("happy");
  await say(`Deset bublinek! Ruce jsou čisté a voňavé.`);

  await offlineChoice("ruce");
  await reflect("ruce", [
    { e: "🧼", t: `Seřadil${g("a", "")} jsem obrázky` },
    { e: "🫧", t: `Praskal${g("a", "")} jsem bublinky` },
    { e: "🙌", t: "Vím, jak se myjí ruce" }
  ]);
  return "done";
}
