/**
 * Ostrov čísel – „Ztracený koláček“ (5–8 min).
 * Vocabulary → one-to-one correspondence → "how many are missing" with a 3-branch hint ladder
 * (Hejný: own strategy; Feuerstein: name the strategy) → attention game → drawing → home task.
 */
import { NUM_WORDS, bearsAcc, plural } from "../czech";
import { nextProgress, outcomeFromMistakes } from "../adaptive";
import { MAX_LEVEL } from "../state";
import { S, save, log, say, setMood, waitFor, html, q, qa, stage, g, cg, tone, boop, melody, shuffle, SCALE } from "../runtime";
import { offlineChoice, reflect, howDidYouKnow, drawPicture } from "./common";

export const LEVELS = { 1: { bears: 3, cakes: 2, maxN: 3 }, 2: { bears: 5, cakes: 3, maxN: 4 } } as const;

export async function run(): Promise<"done" | "declined"> {
  const lv = S.progress.pocitani.level as 1 | 2;
  const { bears, cakes, maxN } = LEVELS[lv];
  const missing = bears - cakes;

  // 1 – invitation: the child may say no
  html(`<div class="row"><button class="big" id="yes">Ano!</button><button class="big soft" id="no">Ještě ne</button></div>`);
  setMood("happy");
  await say(`Ahoj! Chystám piknik pro ${bearsAcc(bears)}. Každý dostane koláček. Pomůžeš mi?`);
  const a = await waitFor([q("#yes"), q("#no")]);
  if (a.id === "no") { await say("Dobře. Až budeš chtít, medvídci tu na tebe počkají."); return "declined"; }

  // 2 – naming
  const items = shuffle([{ e: "🧁", n: "koláček" }, { e: "☕", n: "hrnek" }, { e: "⚽", n: "míč" }]);
  html(`<div class="row">${items.map(i => `<button class="obj" data-n="${i.n}" aria-label="${i.n}">${i.e}</button>`).join("")}</div>`);
  await say("Nejdřív najdi koláček. Ťukni na něj.");
  let tries = 0;
  for (;;) {
    const el = await waitFor(qa(".obj")); tries++;
    if (el.dataset.n === "koláček") {
      tone(784); setMood("happy");
      await say(tries === 1 ? "Ano, to je koláček! Je kulatý a sladký." : `Výborně, teď jsi ho ${g("našla", "našel")}! To je koláček.`);
      break;
    }
    boop();
    if (tries === 1) await say(`To je ${el.dataset.n}. Koláček se dá sníst. Zkusíš to znovu?`);
    else { q('[data-n="koláček"]').classList.add("hint"); await say("Podívej, tenhle svítí. Je to on?"); }
  }
  log("kolacek", "pojmenovani", outcomeFromMistakes(tries - 1), `koláček na ${tries}. pokus`);

  // 3 – one cake for each bear
  html(`<div class="row" id="bears">${Array.from({ length: bears }, (_, i) => `<div class="bear" id="b${i}"><span class="face">🧸</span><div class="plate" id="p${i}"></div></div>`).join("")}</div>
    <div class="table" id="table">${Array.from({ length: cakes }, (_, i) => `<button class="obj" id="c${i}" aria-label="koláček">🧁</button>`).join("")}</div>`);
  await say("Medvídci mají hlad. Ťukni na koláček a dám ho medvídkovi.");
  for (let i = 0; i < cakes; i++) {
    const el = await waitFor(qa(".table .obj:not(.gone)"));
    el.classList.add("gone");
    q(`#p${i}`).innerHTML = `<span class="pop">🧁</span>`;
    q(`#b${i}`).classList.add("fed");
    tone(SCALE[i]);
    await say(NUM_WORDS[i + 1]);
  }

  // 4 – how many are missing: independent / hint / model
  q("#table").remove();
  stage().insertAdjacentHTML("beforeend", `<div class="row" id="nums">${Array.from({ length: maxN }, (_, i) =>
    `<button class="num" data-v="${i + 1}" aria-label="${i + 1}">${i + 1}<span class="dots">${"<i></i>".repeat(i + 1)}</span></button>`).join("")}</div>`);
  setMood("thinking");
  await say(`Ale ${missing === 1 ? "jeden medvídek nemá" : "někteří medvídci nemají"} nic! Kolik koláčků nám chybí?`);
  let wrong = 0;
  for (;;) {
    const v = +(await waitFor(qa(".num"))).dataset.v!;
    if (v === missing) { tone(988); setMood("happy"); break; }
    wrong++; boop();
    if (wrong === 1) {
      qa(".plate").forEach(p => { if (!p.innerHTML) p.classList.add("hint"); });
      setMood("thinking");
      await say("Hmm, podívej se na talíře. Které jsou prázdné? Zkus to znovu.");
    } else {
      setMood(null);
      await say("Já se taky někdy spletu. Spočítáme to spolu.");
      let k = 0;
      for (const p of qa(".plate")) {
        if (!p.innerHTML.includes("🧁")) { k++; p.classList.remove("hint"); p.innerHTML = `<span class="cnt pop">${k}</span>`; tone(SCALE[k]); await say(NUM_WORDS[k]); }
      }
      qa(".num").forEach(n => n.classList.add(+n.dataset.v! === missing ? "hint" : "dim"));
      await say(`Chybí nám ${NUM_WORDS[missing]}. Ťukni na to číslo.`);
      while (+(await waitFor(qa(".num"))).dataset.v! !== missing) boop();
      tone(988);
      break;
    }
  }
  const res = outcomeFromMistakes(wrong);
  log("kolacek", "pocitani", res, `chybělo ${missing} z ${bears} (úroveň ${lv})`);
  S.progress.pocitani = nextProgress(S.progress.pocitani, [res], MAX_LEVEL.pocitani); save();

  if (res === "sama") {
    await howDidYouKnow(`Ano, chybí ${NUM_WORDS[missing]}! Jak jsi na to ${g("přišla", "přišel")}?`, [
      { e: "🧸", t: `Spočítal${g("a", "")} jsem medvídky`, key: "spočítal(a) medvídky", fb: "Spočítat medvídky je chytrý nápad." },
      { e: "🍽️", t: `Viděl${g("a", "")} jsem prázdné talíře`, key: "viděl(a) prázdné talíře", fb: "Všimnout si prázdných talířů, to je bystré." },
      { e: "💡", t: `Prostě jsem to věděl${g("a", "")}`, key: "věděl(a) to hned", fb: "Tak to máš v hlavě kouzelné počítadlo." }
    ]);
  } else {
    setMood("happy");
    await say(`Spolu jsme na to přišli. A ty jsi to ${g("zkoušela", "zkoušel")} dál, to se mi líbí.`);
  }

  // 5 – attention: find the hidden cakes
  const nb = 4;
  const hidden = shuffle([...Array(nb).keys()]).slice(0, missing);
  html(`<div class="row">${Array.from({ length: nb }, (_, i) => `<button class="basket" data-i="${i}" aria-label="košík">🧺</button>`).join("")}</div>`);
  await say(`Chybějící ${plural(missing, "koláček", "koláčky", "koláčků")} jsem ${cg("schovala", "schoval")} do košíků. Najdeš ${missing === 1 ? "ho" : "je"}?`);
  let found = 0, taps = 0;
  while (found < missing) {
    const b = await waitFor(qa(".basket:not(.open)")); taps++;
    b.classList.add("open");
    if (hidden.includes(+b.dataset.i!)) {
      b.textContent = "🧁"; b.classList.add("pop"); found++; tone(SCALE[found + 2]);
      if (found < missing) await say("Jeden je tady! Hledej dál.");
    } else { b.textContent = "🐭"; boop(); await say("Tady je jen myška. Zkus jiný košík."); }
  }
  log("kolacek", "pozornost", taps <= missing + 1 ? "sama" : "napoveda", `${taps} ťuknutí na ${missing} schovaných`);
  html(`<div class="row">${Array.from({ length: bears }, () => `<div class="bear fed"><span class="face">🧸</span><div class="plate"><span class="pop">🧁</span></div></div>`).join("")}</div>`);
  setMood("happy"); void melody();
  await say("Hurá! Každý medvídek má svůj koláček. Děkujeme!");

  // 6–8
  await drawPicture("Teď si nakresli svůj vlastní koláček. Jakou bude mít barvu?", "To je krásný koláček! Pověsím si ho v domečku na zeď.");
  await offlineChoice("kolacek");
  await reflect("kolacek", [
    { e: "🧸", t: `Pomohl${g("a", "")} jsem medvídkům` },
    { e: "🔁", t: `Zkusil${g("a", "")} jsem to znovu` },
    { e: "🎨", t: `Nakreslil${g("a", "")} jsem koláček` }
  ]);
  return "done";
}
