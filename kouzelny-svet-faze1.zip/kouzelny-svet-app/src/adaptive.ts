/**
 * Adaptive difficulty. Pure and unit-tested.
 * Principles from the master prompt:
 *  - adapt on repeated observations, never on a single failure,
 *  - speed is never an input (rychlost ≠ schopnost),
 *  - a modelled answer (postavička ukázala) never counts as success.
 */
export type Outcome = "sama" | "napoveda" | "ukazka";

export interface SkillProgress {
  level: number;
  /** consecutive successful rounds */
  streak: number;
  /** consecutive struggling rounds */
  struggle: number;
}

export interface RoundSummary {
  items: number;
  independent: number;
  modelled: number;
  kind: "success" | "struggle" | "mixed";
}

export function summarize(outcomes: Outcome[]): RoundSummary {
  const items = outcomes.length;
  const independent = outcomes.filter(o => o === "sama").length;
  const modelled = outcomes.filter(o => o === "ukazka").length;
  if (items === 0) return { items, independent, modelled, kind: "mixed" };
  const ratio = independent / items;
  let kind: RoundSummary["kind"] = "mixed";
  if (ratio >= 0.8 && modelled === 0) kind = "success";
  else if (modelled * 2 >= items || ratio <= 0.2) kind = "struggle";
  return { items, independent, modelled, kind };
}

/** Rounds in a row needed before the level changes. */
export const ROUNDS_TO_CHANGE = 2;

export function nextProgress(p: SkillProgress, outcomes: Outcome[], maxLevel: number): SkillProgress {
  const s = summarize(outcomes);
  const out: SkillProgress = { ...p };
  if (s.kind === "success") {
    out.streak = p.streak + 1;
    out.struggle = 0;
    if (out.streak >= ROUNDS_TO_CHANGE && out.level < maxLevel) {
      out.level++;
      out.streak = 0;
    }
  } else if (s.kind === "struggle") {
    out.streak = 0;
    out.struggle = p.struggle + 1;
    if (out.struggle >= ROUNDS_TO_CHANGE && out.level > 1) {
      out.level--;
      out.struggle = 0;
    }
  } else {
    out.streak = 0;
    out.struggle = 0;
  }
  out.level = Math.min(maxLevel, Math.max(1, out.level));
  return out;
}

/** Outcome of one item from the number of wrong attempts before the right one. */
export function outcomeFromMistakes(wrong: number): Outcome {
  return wrong === 0 ? "sama" : wrong === 1 ? "napoveda" : "ukazka";
}
