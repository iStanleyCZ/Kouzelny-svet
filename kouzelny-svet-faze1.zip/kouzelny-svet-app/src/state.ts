/** App state: shape, defaults, loading with migration from the prototype, saving. */
import type { Outcome, SkillProgress } from "./adaptive";

export type SkillId = "pocitani" | "slabiky" | "posloupnost";
export type LogSkill = SkillId | "pojmenovani" | "pozornost";
export type AssistantId = "fousek" | "lili" | "bublik";

export const MAX_LEVEL: Record<SkillId, number> = { pocitani: 2, slabiky: 2, posloupnost: 2 };

export interface LogEntry { t: number; lesson: string; skill: LogSkill; res: Outcome; d: string }
export interface AppState {
  v: 2;
  assistant: AssistantId | null;
  girl: boolean;
  name: string;
  limitMin: number;
  rate: number;
  progress: Record<SkillId, SkillProgress>;
  log: LogEntry[];
  strategies: { t: number; s: string }[];
  offline: { t: number; lesson: string; task: string }[];
  proud: { t: number; lesson: string; a: string }[];
  gallery: { t: number; img: string }[];
  stars: Record<string, number>;
}

export const KEY = "kouzelny-svet-v2";
export const LEGACY_KEY = "kouzelny-svet-v1";
const LOG_MAX = 500;

const fresh = (): SkillProgress => ({ level: 1, streak: 0, struggle: 0 });

export function defaults(): AppState {
  return {
    v: 2, assistant: null, girl: true, name: "", limitMin: 10, rate: 0.92,
    progress: { pocitani: fresh(), slabiky: fresh(), posloupnost: fresh() },
    log: [], strategies: [], offline: [], proud: [], gallery: [], stars: {}
  };
}

const isObj = (x: unknown): x is Record<string, any> => !!x && typeof x === "object" && !Array.isArray(x);
const arr = <T>(x: unknown): T[] => (Array.isArray(x) ? (x as T[]) : []);
const clampInt = (x: unknown, lo: number, hi: number, dflt: number) =>
  typeof x === "number" && Number.isFinite(x) ? Math.min(hi, Math.max(lo, Math.round(x))) : dflt;

/** Turn anything we find in storage (v2, the v1 prototype, or junk) into a valid state. */
export function normalize(raw: unknown): AppState {
  const d = defaults();
  if (!isObj(raw)) return d;
  const s: AppState = { ...d };
  if (raw.assistant === "fousek" || raw.assistant === "lili" || raw.assistant === "bublik") s.assistant = raw.assistant;
  if (typeof raw.girl === "boolean") s.girl = raw.girl;
  if (typeof raw.name === "string") s.name = raw.name.slice(0, 20);
  if ([5, 10, 15, 20].includes(raw.limitMin)) s.limitMin = raw.limitMin;
  if (typeof raw.rate === "number" && raw.rate >= 0.6 && raw.rate <= 1.3) s.rate = raw.rate;
  for (const k of Object.keys(MAX_LEVEL) as SkillId[]) {
    const p = isObj(raw.progress) && isObj(raw.progress[k]) ? raw.progress[k] : null;
    // v1 prototype kept {lv:{pocitani}, streak:{pocitani}}
    const lv = p ? p.level : isObj(raw.lv) ? raw.lv[k] : undefined;
    const st = p ? p.streak : isObj(raw.streak) ? raw.streak[k] : undefined;
    s.progress[k] = {
      level: clampInt(lv, 1, MAX_LEVEL[k], 1),
      streak: clampInt(st, 0, 10, 0),
      struggle: clampInt(p?.struggle, 0, 10, 0)
    };
  }
  s.log = arr<LogEntry>(raw.log).filter(e => isObj(e) && typeof e.t === "number" && typeof e.skill === "string").slice(-LOG_MAX);
  s.strategies = arr(raw.strategies);
  s.offline = arr(raw.offline);
  s.proud = arr(raw.proud);
  s.gallery = arr<{ t: number; img: string }>(raw.gallery).filter(g => isObj(g) && typeof g.img === "string").slice(0, 8);
  if (isObj(raw.stars)) for (const [k, v] of Object.entries(raw.stars)) if (typeof v === "number") s.stars[k] = v;
  return s;
}

type Store = Pick<Storage, "getItem" | "setItem" | "removeItem">;

export function load(store: Store | null): AppState {
  if (!store) return defaults();
  try {
    const cur = store.getItem(KEY);
    if (cur) return normalize(JSON.parse(cur));
    const legacy = store.getItem(LEGACY_KEY);
    if (legacy) {
      const s = normalize(JSON.parse(legacy));
      save(store, s);
      return s;
    }
  } catch { /* corrupt or blocked storage: start fresh */ }
  return defaults();
}

export function save(store: Store | null, s: AppState): boolean {
  if (!store) return false;
  try { store.setItem(KEY, JSON.stringify(s)); return true; } catch { return false; }
}

export function wipe(store: Store | null) {
  try { store?.removeItem(KEY); store?.removeItem(LEGACY_KEY); } catch { /* ignore */ }
}

export function addLog(s: AppState, e: LogEntry) {
  s.log.push(e);
  if (s.log.length > LOG_MAX) s.log.splice(0, s.log.length - LOG_MAX);
}

export function safeStorage(): Store | null {
  try { const ls = window.localStorage; ls.getItem("x"); return ls; } catch { return null; }
}
