/** Characters: art, voice pitch, grammatical gender, how they introduce themselves. */
import type { AssistantId } from "./state";

export interface Character { name: string; full: string; pitch: number; fem: boolean; hi: string; tag: string; svg: () => string }

export const CH: Record<AssistantId, Character> = {
 fousek:{name:"Fousek",full:"Fousek Kapelník",pitch:1.05,fem:false,hi:"Hraju a počítám do rytmu",tag:"Hraje a počítá do rytmu",svg:()=>`<svg viewBox="0 0 200 230" class="ch" aria-hidden="true"><g class="body">
<path d="M150 196 Q198 186 186 136 Q181 116 168 124" fill="none" stroke="#2B2638" stroke-width="16" stroke-linecap="round"/>
<ellipse cx="100" cy="182" rx="52" ry="44" fill="#2B2638"/><ellipse cx="100" cy="190" rx="30" ry="33" fill="#FFF"/>
<ellipse cx="72" cy="216" rx="16" ry="11" fill="#FFF"/><ellipse cx="128" cy="216" rx="16" ry="11" fill="#FFF"/>
<g class="head"><polygon points="52,72 58,20 92,54" fill="#2B2638"/><polygon points="148,72 142,20 108,54" fill="#2B2638"/>
<polygon points="61,60 64,34 83,52" fill="#F4A9C0"/><polygon points="139,60 136,34 117,52" fill="#F4A9C0"/>
<circle cx="100" cy="94" r="52" fill="#2B2638"/><ellipse cx="100" cy="114" rx="29" ry="21" fill="#FFF"/>
<g class="eyes"><ellipse cx="79" cy="88" rx="12" ry="13" fill="#F6D45B"/><ellipse cx="121" cy="88" rx="12" ry="13" fill="#F6D45B"/><ellipse cx="80" cy="90" rx="5.5" ry="9" fill="#1A1622"/><ellipse cx="122" cy="90" rx="5.5" ry="9" fill="#1A1622"/><circle cx="83" cy="84" r="3" fill="#fff"/><circle cx="125" cy="84" r="3" fill="#fff"/></g>
<polygon points="94,105 106,105 100,112" fill="#E07A9A"/>
<path class="m-closed" d="M89 118 Q95 124 100 118 Q105 124 111 118" fill="none" stroke="#1A1622" stroke-width="2.6" stroke-linecap="round"/>
<ellipse class="m-open" cx="100" cy="121" rx="7" ry="6.5" fill="#7A2E4A"/>
<path d="M36 104 L68 110 M36 118 L68 116 M164 104 L132 110 M164 118 L132 116" stroke="#C9C1D6" stroke-width="2" stroke-linecap="round"/>
<circle cx="70" cy="120" r="6" fill="#F4A9C0" opacity=".7"/><circle cx="130" cy="120" r="6" fill="#F4A9C0" opacity=".7"/></g>
<polygon points="100,146 74,134 74,160" fill="#8E5CC9"/><polygon points="100,146 126,134 126,160" fill="#8E5CC9"/><circle cx="100" cy="146" r="7" fill="#6B3FA8"/>
<g class="baton"><line x1="140" y1="172" x2="178" y2="128" stroke="#F3EEDD" stroke-width="5" stroke-linecap="round"/><ellipse cx="140" cy="174" rx="12" ry="10" fill="#FFF"/>
<polygon points="182,108 186,119 198,119 189,126 192,138 182,131 172,138 175,126 166,119 178,119" fill="#F2B83A"/></g></g></svg>`},
 lili:{name:"Lili",full:"Sova Lili",pitch:1.3,fem:true,hi:"Ráda vyprávím a vysvětluju",tag:"Vypráví a vysvětluje",svg:()=>`<svg viewBox="0 0 200 230" class="ch" aria-hidden="true"><g class="body">
<ellipse cx="100" cy="140" rx="72" ry="82" fill="#9B6BD6"/><ellipse cx="100" cy="162" rx="44" ry="54" fill="#E9DCFA"/>
<path d="M70 150 q8 8 16 0 M92 172 q8 8 16 0 M114 150 q8 8 16 0" fill="none" stroke="#C3A6EC" stroke-width="3"/>
<ellipse cx="34" cy="150" rx="16" ry="40" fill="#7D4DBE"/><ellipse cx="166" cy="150" rx="16" ry="40" fill="#7D4DBE"/>
<g class="head"><polygon points="44,62 52,26 76,52" fill="#7D4DBE"/><polygon points="156,62 148,26 124,52" fill="#7D4DBE"/>
<g class="eyes"><circle cx="74" cy="94" r="26" fill="#fff"/><circle cx="126" cy="94" r="26" fill="#fff"/><circle cx="76" cy="96" r="12" fill="#2A1F3D"/><circle cx="124" cy="96" r="12" fill="#2A1F3D"/><circle cx="80" cy="91" r="4" fill="#fff"/><circle cx="128" cy="91" r="4" fill="#fff"/></g>
<polygon class="m-closed" points="90,118 110,118 100,134" fill="#F2B83A"/>
<g class="m-open"><polygon points="90,116 110,116 100,126" fill="#F2B83A"/><polygon points="92,128 108,128 100,138" fill="#E09A20"/></g></g>
<ellipse cx="82" cy="220" rx="12" ry="6" fill="#F2B83A"/><ellipse cx="118" cy="220" rx="12" ry="6" fill="#F2B83A"/></g></svg>`},
 bublik:{name:"Bublík",full:"Bublík",pitch:1.45,fem:false,hi:"Občas se spletu, ale vždycky to zkusím znovu",tag:"Plete se a zkouší to znovu",svg:()=>`<svg viewBox="0 0 200 230" class="ch" aria-hidden="true"><g class="body">
<path d="M100 30 C150 30 176 90 178 150 C180 200 150 222 100 222 C50 222 20 200 22 150 C24 90 50 30 100 30Z" fill="#7FB8F0"/>
<ellipse cx="72" cy="66" rx="14" ry="8" fill="#B8DAFA" transform="rotate(-30 72 66)"/>
<g class="head"><g class="eyes"><circle cx="78" cy="118" r="15" fill="#fff"/><circle cx="122" cy="118" r="15" fill="#fff"/><circle cx="80" cy="120" r="7" fill="#22324F"/><circle cx="124" cy="120" r="7" fill="#22324F"/></g>
<path class="m-closed" d="M84 152 Q100 166 116 152" fill="none" stroke="#22324F" stroke-width="4" stroke-linecap="round"/>
<ellipse class="m-open" cx="100" cy="156" rx="12" ry="9" fill="#22324F"/>
<circle cx="62" cy="146" r="8" fill="#F4A9C0" opacity=".7"/><circle cx="138" cy="146" r="8" fill="#F4A9C0" opacity=".7"/></g></g></svg>`}
};
