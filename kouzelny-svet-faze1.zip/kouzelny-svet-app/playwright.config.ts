import { defineConfig } from "@playwright/test";
import { existsSync } from "node:fs";

// Use the preinstalled Chromium when the matching Playwright build can't be downloaded.
const local = "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome";
const launchOptions = existsSync(local) ? { executablePath: local } : {};

export default defineConfig({
  testDir: "tests/e2e",
  timeout: 90_000,
  expect: { timeout: 10_000 },
  fullyParallel: true,
  workers: 3,
  reporter: [["list"]],
  use: { baseURL: "http://localhost:4173", launchOptions, hasTouch: true, trace: "retain-on-failure" },
  webServer: { command: "npx vite preview --port 4173 --strictPort", url: "http://localhost:4173", reuseExistingServer: true },
  projects: [
    { name: "ipad-na-sirku", use: { viewport: { width: 1024, height: 768 }, deviceScaleFactor: 2, isMobile: true } },
    { name: "ipad-na-vysku", use: { viewport: { width: 768, height: 1024 }, deviceScaleFactor: 2, isMobile: true } },
    { name: "telefon", use: { viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true } }
  ]
});
