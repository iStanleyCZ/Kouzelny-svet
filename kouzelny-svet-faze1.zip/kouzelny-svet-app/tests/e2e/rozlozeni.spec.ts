import { test, expect, tap, bubble } from "./helpers";
import type { Page } from "@playwright/test";

async function checkScreen(page: Page, name: string) {
  const r = await page.evaluate(() => {
    const vw = innerWidth;
    const out: string[] = [];
    if (document.documentElement.scrollWidth > vw + 1) out.push(`vodorovné posouvání (${document.documentElement.scrollWidth} > ${vw})`);
    const visible = [...document.querySelectorAll("button")].filter(b => {
      const s = getComputedStyle(b); const rc = b.getBoundingClientRect();
      return rc.width > 0 && rc.height > 0 && s.visibility !== "hidden" && !b.closest("[hidden]");
    });
    for (const b of visible) {
      const rc = b.getBoundingClientRect();
      const label = (b.getAttribute("aria-label") || b.textContent || "").trim();
      if (!label) out.push(`tlačítko bez popisu: ${b.outerHTML.slice(0, 60)}`);
      if (rc.left < -1 || rc.right > vw + 1) out.push(`mimo obrazovku: ${label}`);
      const kid = b.closest("#stage, #rooms, #pick, .topbar, #s-start, #keypad");
      if (kid && !b.classList.contains("small-btn") && (rc.width < 56 || rc.height < 56)) out.push(`malý dotykový cíl ${Math.round(rc.width)}×${Math.round(rc.height)}: ${label}`);
    }
    return out;
  });
  expect(r, name).toEqual([]);
}

test("všechny obrazovky: bez posouvání do stran, tlačítka dost velká a popsaná", async ({ page, errors }) => {
  void errors;
  await page.goto("/");
  await checkScreen(page, "start");
  await tap(page, "#b-start");
  await checkScreen(page, "výběr kamaráda");
  await tap(page, "#pick-fousek"); await tap(page, "#b-pick");
  await checkScreen(page, "domeček");
  await tap(page, "#room-kolacek"); await page.locator("#yes").waitFor();
  await checkScreen(page, "koláček: pozvánka");
  await tap(page, "#yes"); await page.locator(".obj").first().waitFor();
  await checkScreen(page, "koláček: předměty");
  await tap(page, '.obj[data-n="koláček"]'); await page.locator(".bear").first().waitFor();
  await checkScreen(page, "koláček: medvídci");
  await tap(page, "#b-home");
  await tap(page, "#room-slabiky"); await page.locator("#drum").waitFor({ timeout: 20_000 });
  await checkScreen(page, "slabiky");
  await tap(page, "#b-home");
  await tap(page, "#room-ruce"); await page.locator(".card").first().waitFor();
  await checkScreen(page, "mytí rukou");
  await bubble(page, "úplně první");
  const rows = await page.evaluate(() => new Set([...document.querySelectorAll(".slot")].map(e => Math.round(e.getBoundingClientRect().top))).size);
  expect(rows, "políčka posloupnosti v jedné řadě").toBe(1);
  await page.screenshot({ path: `test-results/ruce-${test.info().project.name}.png` });
  await tap(page, "#b-home");
  await tap(page, "#b-parent");
  await checkScreen(page, "brána");
});
