import { test, expect, tap } from "./helpers";

test("aplikace jde spustit bez internetu", async ({ page, context, errors }) => {
  void errors;
  test.skip(test.info().project.name !== "ipad-na-sirku", "stačí jednou");
  await page.goto("/");
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload();
  await expect.poll(() => page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
  await context.setOffline(true);
  await page.reload();
  await tap(page, "#b-start");
  await tap(page, "#pick-fousek");
  await tap(page, "#b-pick");
  await tap(page, "#room-ruce");
  await expect(page.locator(".card").first()).toBeVisible({ timeout: 20_000 });
  await context.setOffline(false);
});

test("manifest pro instalaci na plochu", async ({ request }) => {
  const m = await (await request.get("/manifest.webmanifest")).json();
  expect(m.name).toBe("Kouzelný svět");
  expect(m.lang).toBe("cs");
  expect(m.display).toBe("standalone");
  for (const i of m.icons) expect((await request.get("/" + i.src)).status()).toBe(200);
});
