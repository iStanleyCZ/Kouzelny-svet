import { test, expect, seed, tap } from "./helpers";

test("mytí rukou na úrovni 2: šest políček v jedné řadě i na telefonu", async ({ page, errors }) => {
  void errors;
  await seed(page, { progress: { pocitani: { level: 1, streak: 0, struggle: 0 }, slabiky: { level: 1, streak: 0, struggle: 0 }, posloupnost: { level: 2, streak: 0, struggle: 0 } } });
  await page.goto("/");
  await tap(page, "#b-start");
  await tap(page, "#room-ruce");
  await page.locator(".card").first().waitFor();
  await expect(page.locator(".slot")).toHaveCount(6);
  const r = await page.evaluate(() => ({
    rows: new Set([...document.querySelectorAll(".slot")].map(e => Math.round(e.getBoundingClientRect().top))).size,
    overflow: document.documentElement.scrollWidth > innerWidth + 1
  }));
  expect(r).toEqual({ rows: 1, overflow: false });
  await page.screenshot({ path: `test-results/ruce6-${test.info().project.name}.png` });
});
