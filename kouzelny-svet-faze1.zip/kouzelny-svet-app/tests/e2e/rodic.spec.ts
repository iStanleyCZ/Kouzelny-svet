import { test, expect, start, state, tap } from "./helpers";

async function openParent(page: import("@playwright/test").Page) {
  await tap(page, "#b-parent");
  await tap(page, '#keypad button:text-is("1")');
  await tap(page, '#keypad button:text-is("OK")');
  await expect(page.locator("#gate-err")).toContainText("nesedí");
  const word = (await page.textContent("#gate-word"))!.trim();
  const n = await page.evaluate(w => {
    const T: Record<string, number> = { dvacet: 20, "třicet": 30, "čtyřicet": 40 };
    const O: Record<string, number> = { jedna: 1, dva: 2, "tři": 3, "čtyři": 4, "pět": 5, "šest": 6, sedm: 7, osm: 8, "devět": 9 };
    const [a, b] = w.split(" "); return (T[a] ?? 0) + (O[b] ?? 0);
  }, word);
  expect(n).toBeGreaterThanOrEqual(21);
  for (const d of String(n)) await tap(page, `#keypad button:text-is("${d}")`);
  await tap(page, '#keypad button:text-is("OK")');
  await expect(page.locator("#s-parent")).toBeVisible();
}

test("brána pustí jen se správným číslem a přehled ukáže prázdný stav", async ({ page, errors }) => {
  void errors;
  await start(page);
  await openParent(page);
  await expect(page.locator(".skill")).toHaveCount(5);
  await expect(page.locator("#parent")).toContainText("Zatím nevyzkoušeno");
  await expect(page.locator("#parent")).not.toContainText(/IQ|diagnóz[ay]\b(?! ani)/);
});

test("nastavení se uloží a projeví", async ({ page, errors }) => {
  void errors;
  await start(page);
  await openParent(page);
  await page.fill("#nm", "Ema");
  await tap(page, "#nm-save");
  await tap(page, '[data-g="0"]');
  await tap(page, '[data-m="15"]');
  await tap(page, '[data-r="0.8"]');
  const s = await state(page);
  expect([s.name, s.girl, s.limitMin, s.rate]).toEqual(["Ema", false, 15, 0.8]);
  await tap(page, "#b-parent-back");
  await expect(page.locator("#house-title")).toHaveText("Domeček – Ema");
  await page.reload();
  await tap(page, "#b-start");
  await expect(page.locator("#house-title")).toHaveText("Domeček – Ema");
});

test("jméno se nedá zneužít k vložení HTML", async ({ page, errors }) => {
  void errors;
  await start(page);
  await openParent(page);
  await page.fill("#nm", '<img src=x onerror=alert(1)>');
  await tap(page, "#nm-save");
  await tap(page, "#b-parent-back");
  await expect(page.locator("#house-title img")).toHaveCount(0);
  await expect(page.locator("#house-title")).toContainText("<img");
  await openParent(page);
  await expect(page.locator("#parent img")).toHaveCount(0);
  await expect(page.locator("#nm")).toHaveValue(/^<img/);
});

test("export dat a smazání všeho", async ({ page, errors }) => {
  void errors;
  await start(page);
  await openParent(page);
  await tap(page, "#exp");
  const json = JSON.parse(await page.inputValue("#exp-ta"));
  expect(json.v).toBe(2);
  expect(json.assistant).toBe("fousek");
  await tap(page, "#del");
  await tap(page, "#del-yes");
  await expect(page.locator("#s-start")).toBeVisible();
  expect(await state(page)).toBeNull();
  await tap(page, "#b-start");
  await expect(page.locator("#s-pick")).toBeVisible();
});
