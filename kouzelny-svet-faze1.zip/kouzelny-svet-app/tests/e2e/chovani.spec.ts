import { test, expect, start, seed, state, bubble, tap, backHome } from "./helpers";

test.describe("reálná rychlost řeči", () => {
  test.use({ fast: false });

  test("ťuknutí během řeči se nezahodí (regrese)", async ({ page, errors }) => {
    void errors;
    await start(page);
    await tap(page, "#room-kolacek");
    await page.locator("#yes").waitFor();
    await page.locator("#yes").click({ force: true }); // Fousek still talking (~5 s of subtitles)
    await expect(page.locator('.obj[data-n="koláček"]')).toBeVisible({ timeout: 3000 });
  });

  test("odchod domů uprostřed lekce lekci opravdu ukončí", async ({ page, errors }) => {
    void errors;
    await start(page);
    await tap(page, "#room-kolacek");
    await page.locator("#yes").waitFor();
    await tap(page, "#b-home");
    await backHome(page);
    await page.waitForTimeout(6500);
    await expect(page.locator("#s-house")).toBeVisible();
    await expect(page.locator("#s-lesson")).toBeHidden();
  });

  test("při nápovědě je buben ztlumený, aby se ťuknutí neztrácela", async ({ page, errors }) => {
    void errors;
    await start(page);
    await tap(page, "#room-slabiky");
    await page.waitForFunction("(()=>{const d=document.querySelector('#drum');return d&&!d.disabled})()", null, { timeout: 30_000 });
    const n = Number(await page.getAttribute(".pic-word", "data-syl"));
    for (let i = 0; i < n + 1; i++) await page.locator("#drum").click({ force: true });
    await tap(page, "#ok");
    await expect(page.locator("#drum")).toBeDisabled();
    await expect(page.locator("#ok")).toBeDisabled();
    await expect(page.locator("#syl span.lit")).toHaveCount(n, { timeout: 15_000 });
    await expect(page.locator("#drum")).toBeEnabled({ timeout: 30_000 });
    await expect(page.locator("#notes i")).toHaveCount(0);
  });

  test("tlačítko zopakuj zopakuje poslední větu", async ({ page, errors }) => {
    void errors;
    await start(page);
    await tap(page, "#room-slabiky");
    await expect(page.locator("#lesson-bubble")).toContainText("orchestru");
    await page.locator("#drum").waitFor({ timeout: 20_000 });
    const before = await page.locator("#lesson-bubble").textContent();
    await page.evaluate(() => (document.getElementById("lesson-bubble")!.textContent = ""));
    await tap(page, "#b-repeat");
    await expect(page.locator("#lesson-bubble")).toHaveText(before!);
  });
});

test("výběr kamaráda: Lili mluví v ženském rodě", async ({ page, errors }) => {
  void errors;
  await seed(page, { assistant: "lili", progress: { pocitani: { level: 1, streak: 0, struggle: 0 }, slabiky: { level: 1, streak: 0, struggle: 0 }, posloupnost: { level: 1, streak: 0, struggle: 0 } } });
  await page.goto("/");
  await tap(page, "#b-start");
  await tap(page, "#room-kolacek");
  await tap(page, "#yes");
  await tap(page, '.obj[data-n="koláček"]');
  await bubble(page, "dám ho medvídkovi");
  const cakes = await page.locator(".table .obj").count();
  expect(cakes).toBe(2);
  for (let i = 0; i < cakes; i++) await tap(page, ".table .obj:not(.gone)");
  await tap(page, '.num[data-v="1"]');
  await tap(page, ".opt >> nth=0");
  await bubble(page, "jsem schovala");
});

test("změna kamaráda se uloží", async ({ page, errors }) => {
  void errors;
  await start(page);
  await tap(page, "#b-friend");
  await tap(page, "#pick-bublik");
  await tap(page, "#b-pick");
  await backHome(page);
  expect((await state(page)).assistant).toBe("bublik");
  await page.reload();
  await tap(page, "#b-start");
  await backHome(page);
});

test("po nastaveném čase přijde přestávka", async ({ page, errors }) => {
  void errors;
  await start(page);
  await page.evaluate(() => ((window as any).__off = 11 * 60_000));
  await tap(page, "#room-kolacek");
  await tap(page, "#b-home");
  await expect(page.locator("#s-break")).toBeVisible();
  await tap(page, "#b-break");
  await backHome(page);
});

test("zamčený pokoj jen promluví, nic nespustí", async ({ page, errors }) => {
  void errors;
  await start(page);
  await tap(page, "#room-emoce");
  await expect(page.locator("#house-bubble")).toContainText("brzy");
  await expect(page.locator("#s-house")).toBeVisible();
});
