import { test, expect, start, seed, state, bubble, tap, playKolacek, playSlabiky, playRuce, backHome } from "./helpers";

test.describe("Ztracený koláček", () => {
  test("cesta s chybami: nápověda, pak ukázka, a vše se zapíše", async ({ page, errors }) => {
    void errors;
    await start(page);
    await playKolacek(page, "chyby");
    const s = await state(page);
    const by = (k: string) => s.log.filter((l: any) => l.skill === k).map((l: any) => l.res);
    expect(by("pojmenovani")).toEqual(["ukazka"]);
    expect(by("pocitani")).toEqual(["ukazka"]);
    expect(s.stars.kolacek).toBe(1);
    expect(s.gallery).toHaveLength(1);
    expect(s.offline[0].lesson).toBe("kolacek");
    expect(s.proud).toHaveLength(1);
    expect(s.progress.pocitani.level).toBe(1);
  });

  test("samostatně dvakrát → příště pět medvídků", async ({ page, errors }) => {
    void errors;
    await start(page);
    expect((await playKolacek(page, "sama")).bears).toBe(3);
    expect((await state(page)).progress.pocitani.level).toBe(1);
    await playKolacek(page, "sama");
    expect((await state(page)).progress.pocitani.level).toBe(2);
    await tap(page, "#room-kolacek");
    await bubble(page, "pět medvídků");
    const s = await state(page);
    expect(s.strategies).toHaveLength(2);
  });

  test("dítě může říct „Ještě ne“", async ({ page, errors }) => {
    void errors;
    await start(page);
    await tap(page, "#room-kolacek");
    await tap(page, "#no");
    await backHome(page);
    expect((await state(page)).stars.kolacek ?? 0).toBe(0);
  });
});

test.describe("Orchestr slabik", () => {
  test("slabiky nejsou vidět dřív, než dítě odpoví (regrese)", async ({ page, errors }) => {
    void errors;
    await start(page);
    await tap(page, "#room-slabiky");
    await page.locator("#drum").waitFor();
    await expect(page.locator("#syl span")).toHaveCount(0);
    await expect(page.locator(".pic-word")).not.toContainText(/\?/);
  });

  test("dvě chyby → ukázka se svítícími slabikami, buben je při nápovědě ztlumený", async ({ page, errors }) => {
    void errors;
    await start(page);
    await playSlabiky(page, true);
    const s = await state(page);
    const res = s.log.filter((l: any) => l.skill === "slabiky").map((l: any) => l.res);
    expect(res).toHaveLength(5);
    expect(res[0]).toBe("ukazka");
    expect(s.progress.slabiky.level).toBe(1);
  });

  test("dvě bezchybná kola → delší slova", async ({ page, errors }) => {
    void errors;
    await start(page);
    await playSlabiky(page);
    expect((await state(page)).progress.slabiky.level).toBe(1);
    await playSlabiky(page);
    expect((await state(page)).progress.slabiky.level).toBe(2);
  });
});

test.describe("Mytí rukou", () => {
  test("pokoj je odemčený a lekce projde s chybou na začátku", async ({ page, errors }) => {
    void errors;
    await start(page);
    expect(await playRuce(page, "chyby")).toBe(4);
    const s = await state(page);
    expect(s.log.find((l: any) => l.skill === "posloupnost").res).toBe("ukazka");
    expect(s.stars.ruce).toBe(1);
  });

  test("samostatně dvakrát → šest kroků", async ({ page, errors }) => {
    void errors;
    await start(page);
    await playRuce(page, "sama");
    await playRuce(page, "sama");
    expect((await state(page)).progress.posloupnost.level).toBe(2);
    expect(await playRuce(page, "sama")).toBe(6);
  });
});

test("pokrok z prototypu se převezme", async ({ page, errors }) => {
  void errors;
  await page.addInitScript(() => {
    if (sessionStorage.getItem("seeded")) return; sessionStorage.setItem("seeded", "1");
    localStorage.setItem("kouzelny-svet-v1", JSON.stringify({ assistant: "lili", girl: true, lv: { pocitani: 2, slabiky: 1 }, streak: {}, stars: { kolacek: 4 }, log: [] }));
  });
  await page.goto("/");
  await tap(page, "#b-start");
  await expect(page.locator("#room-kolacek .stars")).toHaveText("★★★★");
  await tap(page, "#room-kolacek");
  await bubble(page, "pět medvídků");
  await expect(page.locator("#lesson-bubble")).toBeVisible();
  void seed;
});
