import { test as base, expect, type Page } from "@playwright/test";
import handwash from "../../src/content/handwash.json" with { type: "json" };

/** Speeds every timer up so spoken lines (subtitles only in headless) pass quickly. */
export const FAST = `(()=>{const st=window.setTimeout;window.setTimeout=(f,d,...a)=>st(f,Math.max(0,(d||0)/25),...a);})();`;
/** Lets a test move the clock forward for the break timer. */
export const CLOCK = `(()=>{window.__said=[];window.__cur=0;window.__off=0;const n=Date.now.bind(Date);Date.now=()=>n()+window.__off;})();`;

export const test = base.extend<{ fast: boolean; errors: string[] }>({
  fast: [true, { option: true }],
  errors: async ({ page, fast }, use) => {
    const errors: string[] = [];
    page.on("pageerror", e => errors.push(String(e)));
    page.on("console", m => { if (m.type() === "error" && !/fonts\.g|ERR_|Failed to load resource/.test(m.text())) errors.push(m.text()); });
    await page.addInitScript(CLOCK);
    if (fast) await page.addInitScript(FAST);
    await use(errors);
    expect(errors, "chyby v konzoli").toEqual([]);
  }
});
export { expect };

export async function tap(page: Page, sel: string) {
  const l = page.locator(sel).first();
  await l.waitFor({ state: "visible" });
  await l.click({ force: true });
}
/**
 * Wait until the character has said `text` (after everything matched so far).
 * Reads the app's transcript, so a line that was on screen only briefly is not missed,
 * and lines must come in order.
 */
export async function bubble(page: Page, text: string | RegExp, timeout = 20_000) {
  const src = typeof text === "string" ? text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : text.source;
  const flags = typeof text === "string" ? "" : text.flags;
  try {
    await page.waitForFunction(([src, flags]) => {
      const w = window as any; const re = new RegExp(src, flags);
      for (let i = w.__cur; i < w.__said.length; i++) if (re.test(w.__said[i])) { w.__cur = i + 1; return true; }
      return false;
    }, [src, flags] as const, { timeout });
  } catch (e) {
    const tail = await page.evaluate(() => (window as any).__said.slice(-6));
    throw new Error(`Postavička neřekla ${text}. Poslední věty: ${JSON.stringify(tail)}`);
  }
}
export const state = (page: Page) => page.evaluate(() => JSON.parse(localStorage.getItem("kouzelny-svet-v2") || "null"));

export async function seed(page: Page, patch: Record<string, unknown>) {
  await page.addInitScript(p => {
    if (sessionStorage.getItem("seeded")) return;
    sessionStorage.setItem("seeded", "1");
    const base = { v: 2, assistant: "fousek", girl: true, name: "", limitMin: 10, rate: 0.92,
      progress: { pocitani: { level: 1, streak: 0, struggle: 0 }, slabiky: { level: 1, streak: 0, struggle: 0 }, posloupnost: { level: 1, streak: 0, struggle: 0 } },
      log: [], strategies: [], offline: [], proud: [], gallery: [], stars: {} };
    localStorage.setItem("kouzelny-svet-v2", JSON.stringify({ ...base, ...p }));
  }, patch);
}

/** Fresh start: choose Fousek and arrive in the house. */
export async function start(page: Page, who = "fousek") {
  await page.goto("/");
  await tap(page, "#b-start");
  if (await page.locator("#s-pick").isVisible()) {
    await tap(page, `#pick-${who}`);
    await tap(page, "#b-pick");
  }
  await expect(page.locator("#room-kolacek")).toBeVisible();
}
export async function backHome(page: Page) {
  await expect(page.locator("#s-house")).toBeVisible({ timeout: 20_000 });
}

export async function finishCommon(page: Page) {
  // offline task, then reflection
  await bubble(page, "Vyber si");
  await tap(page, ".opt >> nth=0");
  await bubble(page, /pyšn/);
  await tap(page, ".opt >> nth=0");
  await backHome(page);
}

export async function playKolacek(page: Page, mode: "sama" | "chyby") {
  await tap(page, "#room-kolacek");
  await tap(page, "#yes");
  await bubble(page, "Ťukni na něj");
  if (mode === "chyby") {
    await tap(page, '.obj[data-n="hrnek"]'); await bubble(page, "Zkusíš to znovu");
    await tap(page, '.obj[data-n="míč"]'); await bubble(page, "svítí");
  }
  await tap(page, '.obj[data-n="koláček"]');
  await bubble(page, "dám ho medvídkovi");
  await page.locator(".table .obj").first().waitFor();
  const cakes = await page.locator(".table .obj").count();
  expect(cakes).toBeGreaterThan(0);
  for (let i = 0; i < cakes; i++) { await tap(page, ".table .obj:not(.gone)"); await page.waitForTimeout(120); }
  await bubble(page, "chybí?");
  const bears = await page.locator(".bear").count();
  const missing = bears - cakes;
  if (mode === "chyby") {
    const wrong = [1, 2, 3].filter(v => v !== missing);
    await tap(page, `.num[data-v="${wrong[0]}"]`); await bubble(page, "prázdné");
    await tap(page, `.num[data-v="${wrong[1]}"]`); await bubble(page, "Ťukni na to číslo");
    await expect(page.locator(".num.hint")).toHaveCount(1);
    await tap(page, `.num[data-v="${missing}"]`);
    await bubble(page, "zkoušela dál");
  } else {
    await tap(page, `.num[data-v="${missing}"]`);
    await bubble(page, "Jak jsi na to");
    await tap(page, ".opt >> nth=1");
  }
  await bubble(page, "košíků");
  for (let i = 0; i < 4; i++) {
    const left = page.locator(".basket:not(.open)");
    if (!(await left.count()) || !(await page.locator(".basket").count())) break;
    await left.first().click({ force: true }).catch(() => {});
    await page.waitForTimeout(150);
  }
  await bubble(page, "Každý medvídek");
  await bubble(page, "nakresli");
  const box = (await page.locator("#cv").boundingBox())!;
  await page.mouse.move(box.x + 30, box.y + 30); await page.mouse.down();
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 6 }); await page.mouse.up();
  await tap(page, "#done");
  await finishCommon(page);
  return { bears, cakes };
}

export async function playSlabiky(page: Page, firstWordWrongTwice = false) {
  await tap(page, "#room-slabiky");
  const fresh = "(()=>{const d=document.querySelector('#drum');return d&&!d.disabled&&!document.querySelector('#notes i')&&!document.querySelector('#syl span.lit')})()";
  for (let w = 0; w < 5; w++) {
    await page.waitForFunction(fresh, null, { timeout: 20_000 });
    const n = Number(await page.getAttribute(".pic-word", "data-syl"));
    if (w === 0 && firstWordWrongTwice) {
      for (let a = 0; a < 2; a++) {
        for (let i = 0; i < n + 1; i++) await page.locator("#drum").click({ force: true });
        await tap(page, "#ok");
        await bubble(page, a === 0 ? "Teď to zkus ty" : "Ťukneme to spolu");
        await page.waitForFunction("(()=>{const d=document.querySelector('#drum');return d&&!d.disabled&&!document.querySelector('#notes i')})()", null, { timeout: 20_000 });
      }
      await expect(page.locator("#syl span.lit")).toHaveCount(n);
    }
    for (let i = 0; i < n; i++) await page.locator("#drum").click({ force: true });
    await tap(page, "#ok");
    await bubble(page, "Orchestr hraje");
  }
  await finishCommon(page);
}

export async function playRuce(page: Page, mode: "sama" | "chyby") {
  await tap(page, "#room-ruce");
  await bubble(page, "úplně první");
  const slots = await page.locator(".slot").count();
  const correct = slots === 4 ? ["namocit", "namydlit", "oplachnout", "utrit"] : ["pustit", "namocit", "namydlit", "trit", "oplachnout", "utrit"];
  for (let i = 0; i < slots; i++) {
    if (mode === "chyby" && i === 0) {
      const wrong = correct[correct.length - 1];
      await tap(page, `.card[data-id="${wrong}"]`); await bubble(page, "úplně nejdřív");
      await tap(page, `.card[data-id="${wrong}"]`); await bubble(page, "svítí");
      await expect(page.locator(`.card[data-id="${correct[0]}"]`)).toHaveClass(/hint/);
    }
    await tap(page, `.card[data-id="${correct[i]}"]`);
    await bubble(page, (handwash.steps as Record<string, { t: string }>)[correct[i]].t + ".");
  }
  await bubble(page, "Takhle se myjí ruce");
  if (mode === "sama") { await bubble(page, "co přijde dřív"); await tap(page, ".opt >> nth=1"); }
  await bubble(page, "bublinky");
  for (let k = 0; k < 10; k++) { await page.locator(".bub:not(.popped)").first().click({ force: true }); await page.waitForTimeout(60); }
  await bubble(page, "Deset bublinek");
  await finishCommon(page);
  return slots;
}
