import { describe, it, expect } from "vitest";
import { load, save, normalize, defaults, addLog, KEY, LEGACY_KEY } from "../../src/state";
import { summaryBySkill, homeTips } from "../../src/report";

const mem = (init: Record<string, string> = {}) => {
  const m = new Map(Object.entries(init));
  return { getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => void m.set(k, v), removeItem: (k: string) => void m.delete(k), m };
};

describe("ukládání", () => {
  it("bez dat začne výchozím stavem", () => {
    expect(load(mem())).toEqual(defaults());
    expect(load(null)).toEqual(defaults());
  });
  it("přežije poškozená data", () => {
    expect(load(mem({ [KEY]: "{nejde o json" }))).toEqual(defaults());
    expect(normalize("text")).toEqual(defaults());
    expect(normalize({ assistant: "drak", limitMin: 999, rate: 9, progress: { pocitani: { level: 77 } } }).progress.pocitani.level).toBe(2);
  });
  it("přežije zablokované úložiště (soukromé okno)", () => {
    const boom = { getItem: () => { throw new Error("blocked"); }, setItem: () => { throw new Error("blocked"); }, removeItem: () => {} };
    expect(load(boom)).toEqual(defaults());
    expect(save(boom, defaults())).toBe(false);
  });
  it("převezme pokrok z prototypu (v1) a uloží ho jako v2", () => {
    const v1 = { assistant: "fousek", girl: true, name: "Ema", limitMin: 15, rate: 0.92, lv: { pocitani: 2, slabiky: 1 }, streak: { pocitani: 1, slabiky: 0 },
      log: [{ t: 1, lesson: "kolacek", skill: "pocitani", res: "sama", d: "x" }], strategies: [{ t: 1, s: "viděl(a) prázdné talíře" }],
      offline: [], proud: [], gallery: [{ t: 1, img: "data:image/jpeg;base64,AA" }], stars: { kolacek: 3, slabiky: 1 } };
    const store = mem({ [LEGACY_KEY]: JSON.stringify(v1) });
    const s = load(store);
    expect(s.v).toBe(2);
    expect(s.name).toBe("Ema");
    expect(s.limitMin).toBe(15);
    expect(s.progress.pocitani).toEqual({ level: 2, streak: 1, struggle: 0 });
    expect(s.progress.posloupnost.level).toBe(1);
    expect(s.stars.kolacek).toBe(3);
    expect(s.log).toHaveLength(1);
    expect(s.gallery).toHaveLength(1);
    expect(store.m.has(KEY)).toBe(true);
  });
  it("uložit a znovu načíst dá totéž", () => {
    const store = mem(); const s = defaults(); s.name = "Ema"; s.stars.ruce = 2;
    save(store, s);
    expect(load(store)).toEqual(s);
  });
  it("záznam se nerozroste do nekonečna", () => {
    const s = defaults();
    for (let i = 0; i < 700; i++) addLog(s, { t: i, lesson: "x", skill: "slabiky", res: "sama", d: "" });
    expect(s.log).toHaveLength(500);
    expect(s.log[0].t).toBe(200);
  });
});

describe("přehled pro rodiče", () => {
  it("počítá výsledky po dovednostech", () => {
    const s = defaults();
    addLog(s, { t: 5, lesson: "slabiky", skill: "slabiky", res: "sama", d: "" });
    addLog(s, { t: 9, lesson: "slabiky", skill: "slabiky", res: "ukazka", d: "" });
    const r = summaryBySkill(s).find(x => x.skill === "slabiky")!;
    expect([r.sama, r.napoveda, r.ukazka, r.total, r.last]).toEqual([1, 0, 1, 2, 9]);
    expect(r.levelLabel).toBe("krátká slova");
  });
  it("tipy dává až po aspoň dvou pozorováních (žádné závěry z jednoho pokusu)", () => {
    const s = defaults();
    addLog(s, { t: 1, lesson: "slabiky", skill: "slabiky", res: "ukazka", d: "" });
    expect(homeTips(s)).toHaveLength(1);
    expect(homeTips(s)[0]).toMatch(/Zahrajte si/);
    addLog(s, { t: 2, lesson: "slabiky", skill: "slabiky", res: "napoveda", d: "" });
    expect(homeTips(s).join()).toMatch(/Vytleskávejte/);
  });
  it("žádný text nemluví o diagnóze, IQ ani skóre", () => {
    const s = defaults();
    for (const sk of ["slabiky", "pocitani", "posloupnost"] as const)
      for (let i = 0; i < 3; i++) addLog(s, { t: i, lesson: "x", skill: sk, res: i ? "ukazka" : "sama", d: "" });
    expect(homeTips(s).join(" ")).not.toMatch(/diagnóz|IQ|skóre|opožděn|porucha|hyperaktiv/i);
  });
});
