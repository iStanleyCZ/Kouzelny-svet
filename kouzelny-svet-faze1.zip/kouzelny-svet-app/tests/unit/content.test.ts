import { describe, it, expect } from "vitest";
import { WORDS, HANDWASH, OFFLINE, validateContent } from "../../src/content";
import { scramble } from "../../src/lessons/ruce";
import { LEVELS } from "../../src/lessons/kolacek";
import { ROUND } from "../../src/lessons/slabiky";

describe("obsah lekcí", () => {
  it("projde validací", () => {
    expect(validateContent()).toEqual([]);
  });
  it("validace chytí rozbité slovo", () => {
    const bad = { "1": [...WORDS["1"], { w: "kočička", s: ["ko", "či"], e: "🐱" }] };
    expect(validateContent(bad).join()).toMatch(/kočička/);
  });
  it("validace chytí neznámý krok mytí rukou", () => {
    const bad = { ...HANDWASH, levels: { "1": ["namocit", "neexistuje"] } };
    expect(validateContent(WORDS, bad).join()).toMatch(/neexistuje/);
  });
  it("úroveň 1 slabik má jen 1–2 slabiky, úroveň 2 i delší slova", () => {
    expect(WORDS["1"].every(w => w.s.length <= 2)).toBe(true);
    expect(WORDS["2"].some(w => w.s.length >= 3)).toBe(true);
  });
  it("každé kolo slabik má dost slov", () => {
    for (const l of Object.values(WORDS)) expect(l.length).toBeGreaterThanOrEqual(ROUND);
  });
  it("koláček: vždy aspoň jeden chybí a odpověď je mezi tlačítky", () => {
    for (const L of Object.values(LEVELS)) {
      const missing = L.bears - L.cakes;
      expect(missing).toBeGreaterThan(0);
      expect(missing).toBeLessThanOrEqual(L.maxN);
    }
  });
  it("mytí rukou: úroveň 2 obsahuje všechny kroky úrovně 1 ve stejném pořadí", () => {
    const l2 = HANDWASH.levels["2"];
    const idx = HANDWASH.levels["1"].map(id => l2.indexOf(id));
    expect(idx.every(i => i >= 0)).toBe(true);
    expect([...idx].sort((a, b) => a - b)).toEqual(idx);
  });
  it("zamíchání nikdy nevrátí už seřazené pořadí", () => {
    const order = HANDWASH.levels["1"];
    for (let i = 0; i < 300; i++) expect(scramble(order)).not.toEqual(order);
    expect(scramble(order, a => a.slice())).not.toEqual(order);
    expect([...scramble(order)].sort()).toEqual([...order].sort());
  });
  it("každá lekce má 3 úkoly mimo obrazovku", () => {
    for (const k of ["kolacek", "slabiky", "ruce"]) expect(OFFLINE[k]).toHaveLength(3);
  });
});
