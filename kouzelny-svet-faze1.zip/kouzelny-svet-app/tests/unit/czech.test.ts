import { describe, it, expect } from "vitest";
import { numberWord, plural, bearsAcc, syllableLabel, gform } from "../../src/czech";

describe("čeština", () => {
  it("čte čísla jako ve škole", () => {
    expect(numberWord(0)).toBe("nula");
    expect(numberWord(3)).toBe("tři");
    expect(numberWord(10)).toBe("deset");
    expect(numberWord(14)).toBe("čtrnáct");
    expect(numberWord(20)).toBe("dvacet");
    expect(numberWord(27)).toBe("dvacet sedm");
    expect(numberWord(41)).toBe("čtyřicet jedna");
    expect(numberWord(48)).toBe("čtyřicet osm");
  });
  it("odmítne čísla mimo rozsah", () => {
    expect(() => numberWord(100)).toThrow();
    expect(() => numberWord(-1)).toThrow();
    expect(() => numberWord(2.5)).toThrow();
  });
  it("skloňuje podle počtu", () => {
    expect(plural(1, "koláček", "koláčky", "koláčků")).toBe("koláček");
    expect(plural(3, "koláček", "koláčky", "koláčků")).toBe("koláčky");
    expect(plural(5, "koláček", "koláčky", "koláčků")).toBe("koláčků");
    expect(plural(0, "koláček", "koláčky", "koláčků")).toBe("koláčků");
  });
  it("piknik pro tři medvídky / pět medvídků (regrese: dříve 'tři medvídků')", () => {
    expect(bearsAcc(3)).toBe("tři medvídky");
    expect(bearsAcc(5)).toBe("pět medvídků");
    expect(bearsAcc(1)).toBe("jednoho medvídka");
  });
  it("počet slabik", () => {
    expect(syllableLabel(1)).toBe("Jedna slabika");
    expect(syllableLabel(2)).toBe("Dvě slabiky");
    expect(syllableLabel(3)).toBe("Tři slabiky");
    expect(syllableLabel(4)).toBe("Čtyři slabiky");
  });
  it("oslovení podle rodu", () => {
    expect(gform(true, "pyšná", "pyšný")).toBe("pyšná");
    expect(gform(false, "pyšná", "pyšný")).toBe("pyšný");
  });
});
