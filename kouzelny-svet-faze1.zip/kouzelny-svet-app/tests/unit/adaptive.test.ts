import { describe, it, expect } from "vitest";
import { nextProgress, summarize, outcomeFromMistakes, type Outcome, type SkillProgress } from "../../src/adaptive";

const start: SkillProgress = { level: 1, streak: 0, struggle: 0 };
const run = (p: SkillProgress, rounds: Outcome[][], max = 2) => rounds.reduce((acc, r) => nextProgress(acc, r, max), p);
const good: Outcome[] = ["sama", "sama", "sama", "sama", "sama"];
const bad: Outcome[] = ["ukazka", "ukazka", "napoveda", "ukazka", "sama"];

describe("adaptace obtížnosti", () => {
  it("jedno dobré kolo úroveň nezvýší", () => {
    expect(run(start, [good]).level).toBe(1);
  });
  it("dvě dobrá kola za sebou ji zvýší", () => {
    expect(run(start, [good, good]).level).toBe(2);
  });
  it("smíšené kolo mezi nimi sérii přeruší", () => {
    const mixed: Outcome[] = ["sama", "napoveda", "sama", "napoveda", "sama"];
    expect(run(start, [good, mixed, good]).level).toBe(1);
  });
  it("kolo s ukázkou se nepočítá jako úspěch, i když je 4/5 samostatně (regrese z prototypu)", () => {
    const fourPlusModel: Outcome[] = ["sama", "sama", "sama", "sama", "ukazka"];
    expect(summarize(fourPlusModel).kind).not.toBe("success");
    expect(run(start, [fourPlusModel, fourPlusModel]).level).toBe(1);
  });
  it("jedno špatné kolo úroveň nesníží", () => {
    expect(run({ level: 2, streak: 0, struggle: 0 }, [bad]).level).toBe(2);
  });
  it("dvě těžká kola za sebou ji sníží", () => {
    expect(run({ level: 2, streak: 0, struggle: 0 }, [bad, bad]).level).toBe(1);
  });
  it("nikdy nepřekročí maximum ani neklesne pod 1", () => {
    expect(run(start, [good, good, good, good, good, good], 2).level).toBe(2);
    expect(run(start, [bad, bad, bad, bad]).level).toBe(1);
  });
  it("u jednopoložkových kol (koláček) platí totéž", () => {
    expect(run(start, [["sama"]]).level).toBe(1);
    expect(run(start, [["sama"], ["sama"]]).level).toBe(2);
    expect(run({ level: 2, streak: 0, struggle: 0 }, [["ukazka"]]).level).toBe(2);
    expect(run({ level: 2, streak: 0, struggle: 0 }, [["ukazka"], ["ukazka"]]).level).toBe(1);
  });
  it("prázdné kolo nic nezmění", () => {
    expect(nextProgress({ level: 2, streak: 1, struggle: 0 }, [], 2).level).toBe(2);
  });
  it("chyby → výsledek položky", () => {
    expect(outcomeFromMistakes(0)).toBe("sama");
    expect(outcomeFromMistakes(1)).toBe("napoveda");
    expect(outcomeFromMistakes(2)).toBe("ukazka");
    expect(outcomeFromMistakes(5)).toBe("ukazka");
  });
});
